package com.DDDClient.CommonPages;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;
import com.google.common.base.Function;

public class ClientApplication {
	List<String> abc = new ArrayList<String>();
	public WebDriver driver;

	By consumerMenu = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By viewMyConsumers = By.cssSelector("#lnkViewMyConsumers");
	By addClientButton = By.id("ContentPrimary_btnAddClient");
	//By addLastName = By.id("ContentPrimary_txtLastName");
	By addLastName = By.name("ctl00$ContentPrimary$txtLastName");
	//By addFirstName = By.id("ContentPrimary_txtFirstName");
	By addFirstName = By.name("ctl00$ContentPrimary$txtFirstName");
	By addGender = By.name("ctl00$ContentPrimary$ddlGender");
	
	
	
	/*
	 * WebElement addDOBclear =
	 * driver.findElement(By.name("ctl00$ContentPrimary$txtDOB"));
	 * addDOBclear.clear();
	 */
	

    
	//By addDOB = By.name("ctl00$ContentPrimary$txtDOB");
	By addDOB = By.cssSelector("#ContentPrimary_txtDOB");
	//By addDOB = By.id("ContentPrimary_txtDOB");
	//By addDOBContinue = By.id("ContentPrimary_btnAddAndContinue");
	By addDOBContinue = By.name("ctl00$ContentPrimary$btnAddAndContinue");
	// By.xpath("//*[@id=\"ContentPrimary_btnAddAndContinue\"]");
	//By referrredCheckBox = By.cssSelector("#ContentPrimary_dgNewAdd_chkReferred_0");
	// input[@value='Continue']
	By addContinueLink = By.cssSelector("#ContentPrimary_dgNewAdd_Linkbutton2_0");
	By redirectpopop = By.cssSelector("#myModal > div > div > div.modal-footer > button");

	// Responsible Party screen
	By responfirstname = By.id("ContentPrimary_ctrl_ContactAddress_txtContactFN");
	By responlastname = By.id("ContentPrimary_ctrl_ContactAddress_txtContactLN");
	By responhomecheck = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0");
	By responmailcheck = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_1");
	By responaddlineone = By.id("ctl00$ContentPrimary$ctrl_ContactAddress$txtAddressLine1");
	By responaddlinetwo = By.id("ContentPrimary_ctrl_ContactAddress_txtAddressLine2");
	By responaddlinecity = By.id("ContentPrimary_ctrl_ContactAddress_txtCity");
	By responaddzip = By.id("ContentPrimary_ctrl_ContactAddress_txtZip5");
	By responhomephone = By.id("ContentPrimary_ctrl_ContactAddress_txtHomePhonePrefixSuffix");
	By responstartdate = By.id("ContentPrimary_ctrl_ContactAddress_txtAddressStDate");
	By responstodaydate = By.cssSelector("#masterPage > div:nth-child(3) > div.datetimepicker-days > table > tfoot > tr:nth-child(1) > th");
	By responsave = By.id("ContentPrimary_ctrl_ContactAddress_btnSave");
	By responuseentered = By.cssSelector("#ssaddressdialog > div:nth-child(1) > div:nth-child(2) > div > div:nth-child(2) > input");
	By responfinalsave = By.cssSelector("//*[@id=\"myModal\"]/div/div/div[3]/button");

	// Adding Documented Disability
	// Click on Consumer Menu Main again and click on Documented Disabilities
	// Select "At Risk" from Disability and click on Save button. Verify "Save
	// Completed" message

	// Add Consumer Address
	// Consumer
	// Administration->ViewMyConsumers->MyConsumers->Select->ConsumerMainMenu->Add/
	// Edit ConsumerAddress
	By addConAddcons = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By addConAdd = By.id("lnkAddEditConsumerAddr");
	By addConAddminor = By.id("ContentPrimary_ctrl_ContactAddress_chkConsumerEntityType_0");
	By addConAddHome = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0");
	By addConAddlineone = By.id("ContentPrimary_ctrl_ContactAddress_txtAddressLine1");
	By addConAddlinetwo = By.id("ContentPrimary_ctrl_ContactAddress_txtAddressLine2");
	By addConAddcity = By.id("ContentPrimary_ctrl_ContactAddress_txtCity");
	// State Drop down - should select
	By addConAddzip = By.id("ContentPrimary_ctrl_ContactAddress_txtZip5");
	By addConAddhomephone = By.id("ContentPrimary_ctrl_ContactAddress_txtHomePhonePrefixSuffix");
	By addConAddstartdate = By.id("ContentPrimary_ctrl_ContactAddress_txtAddressStDate");
	By addConAddsave = By.id("ContentPrimary_ctrl_ContactAddress_btnSave");
	// Should click on button "Use As Entered" which is showing another window -
	// This is not Alert.
	By addConAddclose = By.xpath("<button class=\"btn btn-default\" type=\"button\" data-dismiss=\"modal\">Close</button>");

	// Add Additional Contact
	By addAddContactconsMenu = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By addAddContact = By.id("lnkAddAdditionalContact");
	By addAddContactGuar = By.id("ContentPrimary_ctrl_ContactAddress_chkContactEntityType_4");
	By addAddContactAgenName = By.id("ContentPrimary_ctrl_ContactAddress_txtAgency");
	By addAddContactexisadd = By.id("ContentPrimary_ctrl_ContactAddress_rblExistingAddr_1");
	By addAddContactsave = By.id("ContentPrimary_ctrl_ContactAddress_btnSave");
	// Should click on button "Use As Entered" which is showing another window -
	// This is not Alert.
	By addAddContactclose = By.xpath("<button class=\"btn btn-default\" type=\"button\" data-dismiss=\"modal\">Close</button>");

	// View Address Book
	By viewAddBookconsMenu = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By viewAddBook = By.id("lnkViewPrintAddressBook");
	By viewAddBookprint = By.id("ContentPrimary_btnPrintAddressBook");

	// Add Disability
	By addDisConsumerMenu = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By addDisdocudis = By.id("lnkDocumentedDiabilities");
	// To be selected Disability from drop down - Code to be here
	By addDis = By.id("ContentPrimary_Button4");

	// Add Etiology
	By addEtiology = By.id("ContentPrimary_btnConcerns");
	// Another window gets opened and select "Autism"
	By addEtiologyeti = By.id("CheckBoxList1_5");
	// Scroll down
	By addEtiologyassign = By.id("btnSave");

	// Add Functional limitations
	By addFunLimitconsumerMenu = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By addFunLimitdocudis = By.id("lnkDocumentedDiabilities");
	By addFunLimit = By.id("ContentPrimary_lbFuncLimit1");
	By addFunLimitselfcare = By.id("ContentPrimary_CheckBox11");
	By addFunLimitassign = By.id("ContentPrimary_btnAssignFuncLimitations");
	By addFunLimitsavefun = By.id("ContentPrimary_Button4");

	// Add Medical Coverage
	By addmedicalcovconsumerMenu = By
			.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By addmedicalcov = By.id("lnkTPL");
	By addmedicalcovaddtpl = By.id("ContentPrimary_lnkAddNew");
	// To select drop down - Type of Coverage
	By addmedicalcovType = By.id("ContentPrimary_ddlTypeOfCoverage");
	By addmedicalcovPolNum = By.id("ContentPrimary_txtPolicyNo");
	By addmedicalcovpolihol = By.id("ContentPrimary_ddlPolicyHoldersName");
	By addmedicalcovGroupNo = By.id("ContentPrimary_txtGroupNo");
	By addmedicalcovPart = By.id("ContentPrimary_ddlPart");
	By addmedicalcovsave = By.id("ContentPrimary_btnSave");
	// Alert - Should be handle after click on Save button in the above line

	// Add evaluation report
	By addevareportcons = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By addevareportdocu = By.id("lnkDocumentedDiabilities");
	By addevareport = By.id("ContentPrimary_lbDisablityPrioirty1");
	By addevareportname = By.id("ContentPrimary_txtProfessionalName");
	By addevareporttitle = By.id("ContentPrimary_txtProfessionalTitle");
	By addevareportType = By.id("ContentPrimary_ddlProfessionalReportType");
	By addevareportDateOfRep = By.id("ContentPrimary_txtProfessionalDateofReport");
	By addevareportsave = By.id("ContentPrimary_btnAssignProfessionalDetails");
	By addevareportFinsave = By.id("ContentPrimary_Button4");

	// ****************************************************************//
	
	// Request DDD Eligibility from same screen again from Consumer main menu, Click on request DDD button
	By reqConsMainMenu = By.cssSelector("#A1");
	By reqDetDDDelig = By.id("btnDetermineEligibility");

	// After SC clicks on DDDEligibility, should not be able to perform any request operation again(Button should be Disable) 
	// operation -The "DetermineEligibility" button Should be Disable mode

	// DDD Eligibility approval process ---
	// Now Supervisor login to approve DDD Eligibility -
	// http://ddqaweb1.preprod.des:8080/organization/ddd/focusdd/frm_Login.aspx
	// Click Consumer Main Menu again and select "Eligibility
	// Determination/Redetermination
	By dddEligDet = By.id("lnkEligibilityDetermination");

	// Match the string Consumer name and click on Edit button to approve DDD
	// Eligibility
	By dddedit = By.id("ContentPrimary_dbgEligibilityDates_lnkViewHistory_0");
	By dddyes = By.id("ContentPrimary_RadioButton1");
	By dddno = By.id("ContentPrimary_RadioButton2");
	By dddsave = By.id("ContentPrimary_btnSaveContinue");
	// After save button, verify the message "Save Successful"	
	

	// Create New ISP Envelope, Add new service and Progress Notes can be added after DDD eligible approval
	
	
	// Create New ISP Envelope, Start date as today, End date can be after 1 month
	// By consumerMenu = By.cssSelector("#bs-example-navbar-collapse-1 >
	// ul:nth-child(2) > li:nth-child(3) > a");
	By newisp = By.id("lnkServicePlan");

	
	// The below items can be added after DDD approval from SCS role ( Supervisor)
	// Add New Service
	// Add Paid Service (HAB / HAN / HPD)

	By addnewser = By.id("ContentPrimary_lnkAddNewService");
	// service drop down and select - HAB / HAN / HPD - Code to be here
	// Should copy ISP start date, End date - Code to be here
	By addnewserrequnits = By.id("ContentPrimary_txtRequestedUnits"); // To be filled 10
	By addnewsersave = By.id("ContentPrimary_btnSave");

	// Add Behavioral Health Code
	By addBehavioalHealthCode = By.id("Hyperlink6");
	By addNewBH = By.id("ContentPrimary_ddl_1"); // Here select the code - F
	// Select the start and end date
	By addAdd = By.id("ContentPrimary_lbAdd_1");

	// Add, Search, Update Progress notes
	By pronotescons = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By pronotes = By.id("lnkProcessNotes");
	By pronotesadd = By.id("ContentPrimary_uccProgressNotes_btnAddNote");
	By pronotescor = By.id("ContentPrimary_uccProgressNotes_ddlCorrespondence");
	// After the above step - Select Correspondence as "OTHER"
	By pronotescate = By.id("ContentPrimary_uccProgressNotes_ddlcategory");
	// After the above step - Select Category as "OTHER"
	By pronotesnar = By.id("ContentPrimary_uccProgressNotes_txtNotes"); // Fill some comments
	By pronotessave = By.id("ContentPrimary_uccProgressNotes_btnSave");
	By pronotesupdate = By.id("ContentPrimary_uccProgressNotes_grdClientNotes_lnkAppend_0");
	By pronotesupnar = By.id("ContentPrimary_uccProgressNotes_txtAppend");
	By pronotesresol = By.id("ContentPrimary_uccProgressNotes_rblActionAppend_2");
	By pronotesresbutton = By.id("ContentPrimary_uccProgressNotes_btnSaveUpdate");

	// Add ACP address consumer address
	By acpconsumerMenu = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By acpviewMyConsumers = By.cssSelector("#lnkViewMyConsumers");
	// Type SC name in worker type and click on My consumers, match with consumer
	// name for whom to add ACP
	// Consumer main menu and Add additional contact
	// Select Guardian check box, Home, Check ACP address, Fill Home phone (Should
	// get from George), Agency name
	// Save

	// Edit Consumer Address
	By editconsumerMenu = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By editconsumeraddress = By.id("lnkAddEditConsumerAddr");
	By editconsumeraddrLineone = By.id("ContentPrimary_ctrl_ContactAddress_txtAddressLine1");

	// Edit additional contact address
	By editconadditional = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By editconaddviewbook = By.id("lnkViewPrintAddressBook");
	By editconaddconta = By.id("ContentPrimary_dbgPersonList_lnkClientContact_0");
	// Up to above line, To add additional contact address, Starting from below is
	// to EDIT them - In this page, change apt number and save it
	By editconaddsave = By.id("ContentPrimary_ctrl_ContactAddress_btnSave");

	// Edit Consumer address
	By editconaddress = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By editconaddresssublink = By.id("lnkAddEditConsumerAddr");
	// Up to above line, To add consumer address- Starting from below line is to
	// EDIT them - In this page, change address line1 and save it
	By editconaddresssave = By.id("ContentPrimary_ctrl_ContactAddress_btnSave");

	// Edit Disability
	// After add new disability, Change it to another Disability. Then click on Save it.

	// Edit Etiology
	By editConsumerMenu = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By editDocudis = By.id("lnkDocumentedDiabilities");
	By editEtiologyadd = By.id("ContentPrimary_btnConcerns");
	// Up to above line is to show to ADD Etiology- Another window gets opened and
	// selected before "Autism", now change it to Autism OR Another disability
	By editEtiologychange = By.id("CheckBoxList1_10");
	// Scroll down
	By editEtiologyassign = By.id("btnSave");

	// Edit Evaluation report
	By editevareportcons = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By editevareportdocu = By.id("lnkDocumentedDiabilities");
	By editevareport = By.id("ContentPrimary_lbDisablityPrioirty1");
	By editevareportname = By.id("ContentPrimary_txtProfessionalName");
	By editevareporttitle = By.id("ContentPrimary_txtProfessionalTitle");
	// Up to above line is to add evaluation report, starting from below line shows
	// to EDIT report actions
	By editevareportType = By.id("ContentPrimary_ddlProfessionalReportType"); // Change the type of evaluation report
	By editevareportDateOfRep = By.id("ContentPrimary_txtProfessionalDateofReport");
	By editevareportsave = By.id("ContentPrimary_btnAssignProfessionalDetails");
	By editevareportFinsave = By.id("ContentPrimary_Button4");

	
	// Edit Functional limitations
	By editFunLimitconsumerMenu = By
			.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By editFunLimitdocudis = By.id("lnkDocumentedDiabilities");
	By editFunLimit = By.id("ContentPrimary_lbFuncLimit1");
	// Up to above line functional limitations is showing by default as Self Care,
	// now change it to "Mobility"
	By editFunLimitselfcare = By.id("ContentPrimary_CheckBox13");
	By editFunLimitassign = By.id("ContentPrimary_btnAssignFuncLimitations");
	By editFunLimitsavefun = By.id("ContentPrimary_Button4");

	
	
	// Edit Medical Coverage
	// Add Medical Coverage
	By editmedicalcovconsumerMenu = By
			.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By editmedicalcov = By.id("lnkTPL");
	By editmedicalcovaddtpl = By.id("ContentPrimary_lnkAddNew");
	// Up to above line- Will show selected - Type of Coverage from drop down,
	// Starting from below line should change Coverage- Medicare
	// Select today's date - Calendar code
	By editmedicalnumber = By.id("ContentPrimary_txtPolicyNo"); // To fill Medicare Number in this line
	By editmedicalpart = By.id("ContentPrimary_ddlPart"); // To select PART here from drop down

	// Edit Behavioral Health Code

	public ClientApplication(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getElement(By element) {
		return driver.findElement(element);
	}

	public void doubleClickElement(By element) {
		Actions action = new Actions(driver);
		WebElement webEl = driver.findElement(element);
		action.doubleClick(webEl).perform();
	}

	public void viewConsumers() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		// Web element consumerMenu =
		// wait.until(ExpectedConditions.elementToBeClickable(consumerMenu)).click();
		wait.until(ExpectedConditions.elementToBeClickable(consumerMenu)).click();
		wait.until(ExpectedConditions.elementToBeClickable(viewMyConsumers)).click();
	}

	public void addConsumers(String firstName, String lastName, String gender, String dateofBirth) {
		try {
			this.getElement(addClientButton).click();
			this.getElement(addLastName).sendKeys(lastName);
			this.getElement(addFirstName).sendKeys(firstName);
			WebElement Gender = driver.findElement(addGender);
			Thread.sleep(6000);
			Select select = new Select(Gender);
			select.selectByValue(gender);
			this.getElement(addDOB).click();
			//this.getElement(addDOB).sendKeys(Keys.BACK_SPACE);
			Thread.sleep(6000);
			//this.getElement(addDOB).click();
			this.getElement(addDOB).sendKeys(dateofBirth);
			Thread.sleep(7000);
			this.doubleClickElement(addDOBContinue);

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,1000)");

			WebDriverWait wait = new WebDriverWait(driver, 100);
			//wait.until(ExpectedConditions.elementToBeClickable(referrredCheckBox)).click();			
			// Add and Continue link by selecting newly created consumer name
			this.getElement(addContinueLink).click();
			Thread.sleep(5000);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public boolean isAlertPresent() {

		boolean presentFlag = false;

		try {
			// Check the presence of alert
			Alert alert = driver.switchTo().alert();
			// Alert present; set the flag
			presentFlag = true;
			// if present consume the alert
			alert.accept();

		} catch (NoAlertPresentException ex) {
			// Alert not present
			ex.printStackTrace();
		}
		return presentFlag;
	}

	public void redirectpopop() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		wait.until(ExpectedConditions.elementToBeClickable(redirectpopop)).click();

	}

	
}
