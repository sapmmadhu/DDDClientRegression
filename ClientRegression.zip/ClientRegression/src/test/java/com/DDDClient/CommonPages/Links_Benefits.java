package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;



public class Links_Benefits {
	public WebDriver driver;

	By LinkBenefits = By.id("lnkSocialServices");
	By LinkAddNewBenefit = By.id("ContentPrimary_lnkAddNewBenefitRecord");
	By LinkAll = By.id("ContentPrimary_chkAllMonths");
	By LinkAmount = By.id("ContentPrimary_TextBox1");
	
	
	public Links_Benefits (WebDriver driver) {
		this.driver = driver;
	}
}