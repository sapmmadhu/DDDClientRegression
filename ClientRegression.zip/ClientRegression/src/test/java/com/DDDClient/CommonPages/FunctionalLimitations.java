package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;


import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;



public class FunctionalLimitations {
	public WebDriver driver;

	By FunctionalLimitations = By.id("ContentPrimary_lbFuncLimit1");
	// Select any functional limitations and click on "Assign to Diagnosis"

	
	// To Edit Functional limitations, Follow the same steps and change the type and click on "Assign to Diagnosis".
	
	public FunctionalLimitations(WebDriver driver) {
	this.driver = driver;
		
		
		
	}
}