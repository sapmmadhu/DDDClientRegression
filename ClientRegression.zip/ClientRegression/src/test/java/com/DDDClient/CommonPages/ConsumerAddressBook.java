package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class ConsumerAddressBook {
	public WebDriver driver;

	By AddConsumerAddress = By.id("lnkAddEditConsumerAddr");
	
	By ResponLastName = By.id("ContentPrimary_ctrl_ContactAddress_txtContactLN");
	By ResponHomeCheck = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0");	
	By ResponMailCheck = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_1");

	public ConsumerAddressBook (WebDriver driver) {
		this.driver = driver;
	}
}