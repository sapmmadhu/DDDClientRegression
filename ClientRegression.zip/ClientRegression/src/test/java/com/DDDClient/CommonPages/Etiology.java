package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;


public class Etiology {
	public WebDriver driver;

	By AddEtiology = By.id("ContentPrimary_btnConcerns");
	By ResponLastname = By.id("ContentPrimary_ctrl_ContactAddress_txtContactLN");
	By ResponHomeCheck = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0");	
	By ResponMailCheck = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_1");

	public Etiology(WebDriver driver) {
		this.driver = driver;
	}
}