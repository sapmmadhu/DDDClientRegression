package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.DDDClient.common.WindowHandler;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;

import java.util.List;
import java.util.concurrent.TimeUnit;

public class Links_ConsumerMainMenu {
	public WebDriver driver;
	// By LinkAliases = By.xpath("//*[text()='Aliases']");
	By LinkAliases = By.id("lnkConsumerAliases");
	By LinkAddNewAliases = By.id("ContentPrimary_lnkAddNew");
	By LinkViewConsumerList = By.id("ContentPrimary_lnkAddNew");

	By consumerMainMenu = By.xpath("//li[@id='liConsumerMenu']//a[contains(text(),'Consumer Main Menu')]");
	By functionalLimitations = By.id("ContentPrimary_lbFuncLimit1");
	By addEvaluationReport = By.id("ContentPrimary_lbDisablityPrioirty1");
	By selfCare = By.xpath("//*[contains(text(),'Self-Care')]");
	By assignToDiagnosis = By.xpath("//input[@name='ctl00$ContentPrimary$btnAssignFuncLimitations']");
	By dropDown = By.xpath("//select[@name='ctl00$ContentPrimary$DropDownList1']");

	// Evaluation report - Added before DDD approval
	By name = By.xpath("//input[@id='ContentPrimary_txtProfessionalName']");
	By title = By.xpath("//input[@id='ContentPrimary_txtProfessionalTitle']");
	By dropDownER = By.xpath("//select[@id='ContentPrimary_ddlProfessionalReportType']");

	
	By ERsave = By.xpath("//input[@value='Save']");
	By dateofReport = By.xpath("//input[@id='ContentPrimary_txtProfessionalDateofReport']");
	By today = By.xpath("//div[@class='datetimepicker-days']//th[contains(text(),'Today')]");

	// Etiology - Added before DDD approval
	By Etiology = By.xpath("//*[@id=\"ContentPrimary_btnConcerns\"]");
	By assignEtiology = By.xpath("//*[@id=\"btnSave\"]");
	By selectEtiology = By.xpath("//input[@value='Select Etiology']");
	By assign = By.xpath("//input[@value='Assign']");
	By ETSave = By.xpath("//input[@value='Save']");

	// Demographics - Added before DDD approval
	By DemographicsLink = By.xpath("//a[contains(text(),'Demographics')]");
	
   // Eligibility - Added before DDD approval
	By EligiDeterButton = By.xpath("//select[@name='ctl00$btnDetermineEligibility']");
	
	// Aliases from Consumer Main Menu - Can add before DDD eligibility approval
	By EligiDeterRedeter = By.xpath("//input[@id='lnkConsumerAliases']");
	
	//Add additional Contact - Can add before DDD eligibility approval
	By AdditionalContact = By.xpath("//input[@id='lnkAddAdditionalContact']");
	
    // Eligibility Dates from Consumer Main Menu - Should be added after approval
	By EligibilityDates = By.xpath("//input[@id='lnkConsumerEligibilityDates']");
	By EligibilityDatesTitle = By.xpath("//a[contains(@id, ContentPrimary_Label44') and contains(@title, 'DIVISION OF DEVELOPMENTAL DISABILITIES')]");
	

	// Add New service
	
	public Links_ConsumerMainMenu(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getElement(By element) {
		return driver.findElement(element);
	}

	public void linkDocumentedDisabilities() throws InterruptedException {
		Thread.sleep(4000);
		this.getElement(consumerMainMenu).click();
		Thread.sleep(5000);
		List<WebElement> listConsumerMenu = driver.findElements(By.xpath("//ul[@class='dropdown-menu mega-dropdown-menu']/li/ul/li"));
		for (WebElement consumerMenu : listConsumerMenu) {
			System.out.println(consumerMenu.getText());
			String menuText = consumerMenu.getText();
			if (menuText.contains("Documented Disabilities")) {
				consumerMenu.click();
				break;
			}
		}
	}

	public void ifConditionClick(WebDriver driver, String text, String functionalLimit, String functionalLimitOne,
			String functionalLimitTwo, String name) {
		if (text.equalsIgnoreCase(name) && functionalLimit.equalsIgnoreCase(name)
				|| (text.equalsIgnoreCase(name) && functionalLimitOne.equalsIgnoreCase(name))
				|| (text.equalsIgnoreCase(name) && functionalLimitTwo.equalsIgnoreCase(name))) {
			driver.findElement(By.xpath("//label[contains(text(),'" + name + "')]")).click();
		}
	}

	public void consumerDocumentedDisabilities(String disabilityName, String functionalLimit, String functionalLimitOne,
			String functionalLimitTwo, String ERName, String ERTitle, String typeOFEvaluation, String etiologyName)
			throws InterruptedException {

		Thread.sleep(5000);
		Select select = new Select(this.getElement(dropDown));
		select.selectByVisibleText(disabilityName);
		Thread.sleep(3000);
		this.getElement(functionalLimitations).click();

		List<WebElement> listofRows = driver.findElements(By.xpath("//*[@id=\"Table11\"]/tbody/tr"));
		for (WebElement list : listofRows) {
			String text = list.getText();
			System.out.println(text);
			ifConditionClick(driver, text, functionalLimit, functionalLimitOne, functionalLimitTwo, "Self-Care");
			ifConditionClick(driver, text, functionalLimit, functionalLimitOne, functionalLimitTwo, "Learning");
			ifConditionClick(driver, text, functionalLimit, functionalLimitOne, functionalLimitTwo, "Self-direction");
			ifConditionClick(driver, text, functionalLimit, functionalLimitOne, functionalLimitTwo, "Mobility");
			ifConditionClick(driver, text, functionalLimit, functionalLimitOne, functionalLimitTwo, "Economic Self-Sufficiency");
			ifConditionClick(driver, text, functionalLimit, functionalLimitOne, functionalLimitTwo, "Capacity for Independent Living");
			ifConditionClick(driver, text, functionalLimit, functionalLimitOne, functionalLimitTwo,	"Receptive and Expressive Language");
		}
		this.getElement(assignToDiagnosis).click();
		Thread.sleep(3000);
		this.getElement(addEvaluationReport).click();
		Thread.sleep(3000);

		// Name
		this.getElement(name).sendKeys(ERName);
		// Title
		this.getElement(title).sendKeys(ERTitle);
		Thread.sleep(5000);
		
		// Type Of Evaluation Report
		Select se = new Select(this.getElement(dropDownER));
		if (typeOFEvaluation.equalsIgnoreCase("Psychological or Psycho-educational")) {
			se.selectByValue("Psychological or Psycho-educational");
		} else if (typeOFEvaluation.equalsIgnoreCase("Neurological")) {
			se.selectByValue("Neurological");
		} else if (typeOFEvaluation.equalsIgnoreCase("Psychiatric")) {
			se.selectByValue("Psychiatric");
		} else if (typeOFEvaluation.equalsIgnoreCase("Developmental")) {
			se.selectByValue("Developmental");
		} else if (typeOFEvaluation.equalsIgnoreCase("Physician")) {
			se.selectByValue("Physician");
		} else if (typeOFEvaluation.equalsIgnoreCase("Other (please specify)")) {
			se.selectByValue("0");
		}

		Thread.sleep(3000);

		this.getElement(dateofReport).click();
		this.getElement(today).click();

		this.getElement(ERsave).click();
		this.getElement(selectEtiology).click();
		
		String winHandleBefore = driver.getWindowHandle();
		for(String winHandle : driver.getWindowHandles()){
		    driver.switchTo().window(winHandle);
		}
		
				
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//label[contains(text(),'"+ etiologyName + "')]//parent::td/input")).click();
		Thread.sleep(5000);				
		this.getElement(assign).click();

		driver.switchTo().window(winHandleBefore);
		Thread.sleep(5000);
		this.getElement(ETSave).click();
		
		
		this.getElement(consumerMainMenu).click();
		Thread.sleep(5000);
		this.getElement(DemographicsLink).click();
		Thread.sleep(5000);
		
		this.getElement(consumerMainMenu).click();
		Thread.sleep(5000);
		//this.getElement(EligiDeterButton).click();
		//Thread.sleep(5000);
		

		// Adding Birth history before DDD eligible request
		
		// Adding additional contact
		
		
		// driver.findElement(By.xpath("//*[text()='Add Additional Contact']")).click();
		// Firstname, Lastname, Addressline1, Addressline2, City, State, Zip, Startdate
		// driver.findElement(By.xpath("//*[text()='Save']")).click();
		// //input[contains(@name,'Email')]		
		
		
		// Add New Service
		
	}
}
