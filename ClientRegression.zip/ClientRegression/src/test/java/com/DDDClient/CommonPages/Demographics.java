package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Demographics {
	public WebDriver driver;

	By DemolangdropDown = By.xpath("//select[@name='ctl00$ContentPrimary$ddlConsumerLanguage']");
	By DemoEthdropDown = By.xpath("//select[@name='ctl00$ContentPrimary$ddlEthnicity']");
	By DemoTribedropdown = By.xpath("//select[@name='ctl00$ContentPrimary$ddlTribe']");
	By DemoIncondropdown = By.xpath("//button[@data-id='ContentPrimary_Incontinent_Dropdownlist']");
	By DemoEmergencyPaln = By.xpath("//select[@name='ctl00$ContentPrimary$PowerDependent_Dropdownlist']");
	By DemoComments =  By.xpath("//textarea[@name='ctl00$ContentPrimary$txtDisabilityDescription']");
	By DemoReason = By.xpath("//select[@name='ctl00$ContentPrimary$ddlICAPReason']");
	By DemoSave = By.xpath("//input[@value='Save']");
	
	
	public Demographics(WebDriver driver) {
		this.driver = driver;
		
	}

	public WebElement getElement(By element) {
		return driver.findElement(element);
	}
	
	public void consdemo(String language, String ethinicity, String tribe, String incontinent, String emergency, String comments) throws InterruptedException {
		
		Actions actions = new Actions(driver);
		actions.moveToElement(this.getElement(DemolangdropDown)).click().build().perform();
		Thread.sleep(5000);
		//this.getElement(DemolangdropDown).click();
		driver.findElement(By.xpath("//span[contains(text(),'"+language+"')]")).click();
		actions.moveToElement(this.getElement(DemoEthdropDown)).click().build().perform();
		//this.getElement(DemoEthdropDown).click();
		driver.findElement(By.xpath("//span[contains(text(),'"+ethinicity+"')]")).click();
		actions.moveToElement(this.getElement(DemoTribedropdown)).click().build().perform();
		//this.getElement(DemoTribedropdown).click();
		driver.findElement(By.xpath("//span[contains(text(),'"+tribe+"')]")).click();
		actions.moveToElement(this.getElement(DemoIncondropdown)).click().build().perform();
		//this.getElement(DemoIncondropdown).click();
		driver.findElement(By.xpath("//button[@data-id='ContentPrimary_Incontinent_Dropdownlist']//following::div//span[contains(text(),'"+incontinent+"')]")).click();
		actions.moveToElement(this.getElement(DemoEmergencyPaln)).click().build().perform();
		//this.getElement(DemoEmergencyPaln).click();
		WebElement  ele=	driver.findElement(By.xpath("//span[contains(text(),'Emergency Planning:')]//following::div//following::div//span[contains(text(),'"+emergency+"')]"));
		//driver.findElement(By.xpath("//div[@class='dropdown bootstrap-select form-control open']//span[contains(text(),'"+emergency+"')]")).click();
		actions.moveToElement(ele).doubleClick().build().perform();
		Thread.sleep(5000);
		
	
		WebDriverWait wait=new WebDriverWait(driver, 20);
		WebElement DemoComments;
		DemoComments= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath( "//textarea[@name='ctl00$ContentPrimary$txtDisabilityDescription']")));
		DemoComments.sendKeys(comments);		
		Thread.sleep(5000);
		
		WebElement DemoSave;
		DemoSave =  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='Save']")));
		DemoSave.click();
		Thread.sleep(5000);
				
	}
	
}
