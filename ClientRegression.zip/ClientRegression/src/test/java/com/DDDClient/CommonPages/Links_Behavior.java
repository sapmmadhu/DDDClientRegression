package com.DDDClient.CommonPages;

import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class Links_Behavior {
	public WebDriver driver;

	By LinkBehavioralCode = By.id("lnkBehavior");
	
	// The message "Please explain"  - The link should be displayed 5 times.
	By LinkPlsExplain = By.id("ContentPrimary_btnChildLikesComments");
	
	public Links_Behavior (WebDriver driver) {
		this.driver = driver;		
	}
}