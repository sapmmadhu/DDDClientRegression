package com.DDDClient.CommonPages;


import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver; 


public class CognitiveIntellectualDisability {

	public WebDriver driver;

	By AddEtiology = By.id("ContentPrimary_btnConcerns");
	By ResponLastname = By.id("ContentPrimary_ctrl_ContactAddress_txtContactLN");
	By ResponHomeCheck = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0");	
	By ResponMailCheck = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_1");

	public CognitiveIntellectualDisability(WebDriver driver) {
		this.driver = driver;
	}
}