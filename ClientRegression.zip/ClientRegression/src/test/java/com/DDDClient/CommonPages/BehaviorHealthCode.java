package com.DDDClient.CommonPages;

import org.openqa.selenium.By;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class BehaviorHealthCode {
	public WebDriver driver;

	By BehavioralCode = By.id("Hyperlink6");
	By ViewHistory = By.id("ContentPrimary_lnkViewHistory");
	

	public BehaviorHealthCode (WebDriver driver) {
		this.driver = driver;
	}
}