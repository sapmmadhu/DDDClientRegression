package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;


public class EvaluationReport {
	public WebDriver driver;

	By EvaluationReport = By.id("ContentPrimary_lbDisablityPrioirty1");
	// Select type of Evaluation Report, Date of report, Name, Title and SAVE
    By EvaluationReportSave = By.id("ContentPrimary_btnAssignProfessionalDetails");
    
    // To Edit, Follow the same steps and change the value from the drop down and save.
    
	public EvaluationReport(WebDriver driver) {
		this.driver = driver;
	}
}