package com.DDDClient.CommonPages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;

public class Links_Dashboard {

	public WebDriver driver;

	public Links_Dashboard (WebDriver driver) {
		this.driver = driver;
	}
	
	/*
	 * public void Dashboard() { 
	 * By LinkDashboard =By.xpath("//*[text()='Dashboard']"); }
	 * driver.click();
	 */
	
	
	
	public void TaskQueue() {
		By LinkTaskQueue = By.id("lnkAugComm");	
		this.driver = driver;	
		//By LinkTaskQueue= By.xpath("//*[text()='Tasks Queue ']");
		}
	
	
	public void ProgressNotes() {
		By LinkProgressNotes = By.id("ContentPrimary_tab2");	
		this.driver = driver;	
		//By LinkProgressNotes= By.xpath("//*[text()='Progress Notes']");
		}
	
	
	public void GlobalNotifications() {
		By LinkGlobalNotifications = By.id("ContentPrimary_tab2");	
		this.driver = driver;	
		//By LinkGlobalNotifications=By.xpath("//*[text()='Global Notifications']");
		}
	
	
	public void ClaimsTracking() {
		By LinkClaimsTracking = By.id("ContentPrimary_tab2");	
		this.driver = driver;		
		//By LinkClaimsTracking= By.xpath("//*[text()='Claims Tracking']");
		}
	
	
	

public void Dashboard() {
	By LinkProgressNotes = By.id("ContentPrimary_ctrl_ContactAddress_txtContactFN");
	By LinkGlobalNoti = By.id("ContentPrimary_ctrl_ContactAddress_txtContactLN");
	By LinkClaimsTracking = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0");	
	this.driver = driver;
}
	
}
