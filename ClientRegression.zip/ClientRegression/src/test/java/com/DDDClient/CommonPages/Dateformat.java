package com.DDDClient.CommonPages;

import java.text.ParseException;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;
import java.text.SimpleDateFormat;
import java.util.Date;


public class Dateformat {

	public  String getDateFormat(String fromDate) throws ParseException {
		String toDate=null;
		try 
		{		
		SimpleDateFormat dt = new SimpleDateFormat("m/d/yyyy"); 
		Date date = dt.parse(fromDate); 
		SimpleDateFormat dt1 = new SimpleDateFormat("mm/dd/yyyy");
		toDate= dt1.format(date);
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("toDate:"+toDate);
		return toDate;
	}
}
