package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;



public class Links_HospitalizationsIllness {
	public WebDriver driver;

	By LinkHospitalizations = By.id("lnkHospitalizationsIllnesses");
	By LinkAddNewHospitalizations = By.id("ContentPrimary_lnkAddNew");
	By LinkViewList = By.id("ContentPrimary_lnkAddNew");
	
	public Links_HospitalizationsIllness (WebDriver driver) {
		this.driver = driver;
	}
}