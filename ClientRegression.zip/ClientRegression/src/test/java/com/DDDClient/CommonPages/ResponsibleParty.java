package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;
import java.util.List;



public class ResponsibleParty {
	public WebDriver driver;

	By ResponFirstName = By.id("ContentPrimary_ctrl_ContactAddress_txtContactFN");
	By ResponLastName = By.id("ContentPrimary_ctrl_ContactAddress_txtContactLN");
	By ResponHomeCheck = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0");	
	By ResponMailCheck = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_1");
	// By responaddlineone = By.id("ctl00$ContentPrimary$ctrl_ContactAddress$txtAddressLine1");
	// #ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0
	By ResponAddLineOne = By.xpath("//input[@name='ctl00$ContentPrimary$ctrl_ContactAddress$txtAddressLine1']");
	By ResponAddLineTwo = By.id("ContentPrimary_ctrl_ContactAddress_txtAddressLine2");
	By ResponAddLineCity = By.id("ContentPrimary_ctrl_ContactAddress_txtCity");
	By ResponState = By.id("ContentPrimary_ctrl_ContactAddress_ddlState");
	// State drop down
	By ResponAddZip = By.id("ContentPrimary_ctrl_ContactAddress_txtZip5");
	By ResponHomePhone = By.id("ContentPrimary_ctrl_ContactAddress_txtHomePhonePrefixSuffix");
	By ResponStartDate = By.id("ContentPrimary_ctrl_ContactAddress_txtAddressStDate");
	//By ResponsTodayDate = By.cssSelector("#masterPage > div:nth-child(3) > div.datetimepicker-days > table > tfoot > tr:nth-child(1) > th");
	By ResponsTodayDate=By.xpath("(//div[@class='datetimepicker-days']//th[contains(text(),'Today')])[1]");
	By ResponSave = By.xpath("//input[@value='Save']");
	By FooterScroll= By.xpath("//*[@id='footerInj']/div[1]");
	By UseAsEntered = By.xpath("//input[@value='Use as Entered']");
	By FinalClose = By.xpath("//button[contains(text(),'Close')]");
	

	public ResponsibleParty(WebDriver driver) {
		this.driver = driver;
	}
		

	public WebElement getElement(By element) {
		return driver.findElement(element);
	}

	public void addResponsibleParty(String reFirstName, String reLastName, String reSelectbox, String reAddlineone, String reAddlinetwo, String reCity, String reState, String reZip, String reHomePhone) throws InterruptedException {

		this.getElement(ResponFirstName).sendKeys(reFirstName);
		this.getElement(ResponLastName).sendKeys(reLastName);
		List<WebElement> checkboxes=driver.findElements(By.xpath("//*[@id='ContentPrimary_ctrl_ContactAddress_chkAddNewAddr']/tbody/tr/td"));
		Thread.sleep(5000);
		for (WebElement boxes : checkboxes) {
			System.out.println(boxes.getText());
			String textValues=boxes.getText();
		//	String reSelectbox="Home";
			if(reSelectbox.contains("Home")&& textValues.contains("Home") ) {
			boxes.click();
			break;
			}
			else if(reSelectbox.contains("Mailing")&& textValues.contains("Mailing") ) {
				boxes.click();
				break;
				}
			else {
				boxes.click();
			}		
			
		}
		Thread.sleep(5000);
		this.getElement(ResponAddLineOne).sendKeys(reAddlineone);
		this.getElement(ResponAddLineTwo).sendKeys(reAddlinetwo);
		this.getElement(ResponAddLineCity).sendKeys(reCity);

		Select dropdown = new Select(driver.findElement(ResponState));
		dropdown.selectByValue(reState);

		this.getElement(ResponAddZip).sendKeys(reZip);		
		this.getElement(ResponHomePhone).sendKeys(reHomePhone);
		driver.manage().window().maximize();
		Thread.sleep(5000);
		this.getElement(FooterScroll).click();
		Thread.sleep(5000);
		this.getElement(ResponStartDate).click();
		//JavascriptExecutor js = (JavascriptExecutor) driver;
		//WebElement ele= this.getElement(ResponsTodayDate);
		//js.executeScript("arguments[0].scrollIntoView();", ele);
		Thread.sleep(3000);
		this.getElement(ResponsTodayDate).click();
		Thread.sleep(5000);
		
		
		WebDriverWait ele = new WebDriverWait(driver,100); 
		ele.until(ExpectedConditions.visibilityOfElementLocated(ResponSave));
		
		this.getElement(ResponSave).click();
		Thread.sleep(3000);
		
		WebDriverWait element = new WebDriverWait(driver,100); 
		element.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='Use as Entered']")));
		//Thread.sleep(7000);
		
		this.getElement(UseAsEntered).click();
		Thread.sleep(5000);
		this.getElement(FinalClose).click();
	}
}
