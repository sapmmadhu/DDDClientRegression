package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;



public class Links_Demographics {
	public WebDriver driver;

	By LinkDemographics = By.id("lnkConsumerDemographics");

	public Links_Demographics (WebDriver driver) {
		this.driver = driver;
	}
}