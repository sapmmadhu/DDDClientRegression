package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;


public class Links_MedicalCoverage {
	public WebDriver driver;

	By LinkMedicalCoverage = By.id("lnkTPL");
	By LinkAddTPLMedical = By.id("ContentPrimary_lnkAddNew");
	By LinkViewListOfCoverage = By.id("ContentPrimary_lnkAddNew");
	
	// To show list all records
	By LinkShowAllRecords = By.id("ContentPrimary_chkShowAllRecords");

	public Links_MedicalCoverage (WebDriver driver) {
		this.driver = driver;
	}
}