package com.DDDClient.CommonPages;

import java.util.List;

import org.apache.commons.codec.binary.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

public class Links_Validations_StdClientRegression {

	public WebDriver driver;

	By thirdPartyLiablity = By.id("lnkTPL");

	public Links_Validations_StdClientRegression(WebDriver driver) {
		this.driver = driver;
	}

	// @Test
	public List<WebElement> getUserAppsList() {

		List<WebElement> userAppsLinks = driver
				.findElements(By.xpath(".//*[@id='divUserApps']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/a"));		
		System.out.println("User Applications"); 
		int size=userAppsLinks.size(); System.out.println(size);		  
		  for(int i=0;i<size;i++){ String name=userAppsLinks.get(i).getText();
		  System.out.println(name); }		 
		return userAppsLinks;

	}

	public List<WebElement> getGlobalApps() {

		List<WebElement> globalAppsLinks = driver
				.findElements(By.xpath("//*[@id='divGlobalApps']/table/tbody/tr[2]/td/table/tbody/tr/td[2]/a"));
		System.out.println("Global Applications");
		int size=globalAppsLinks.size(); System.out.println(size);		  
		  for(int i=0;i<size;i++){ String name=globalAppsLinks.get(i).getText();
		  System.out.println(name); }		
		return globalAppsLinks;

	}


	public void getAHCCCSUtilities() {
		
		List<WebElement> AHCCCSUtilitiesLinks = driver.findElements(By.xpath(".//*[@id='Table2']/tbody/tr/td[2]/a"));
		System.out.println("AHCCCS Utilities");		
		int size=AHCCCSUtilitiesLinks.size(); 
		System.out.println(size);		  
		  for(int i=0;i<size;i++){ String name=AHCCCSUtilitiesLinks.get(i).getText();
		  System.out.println(name); }
	}
	
	
	// To Be Started from here	
	public void getBehaviorHealthApplication() {
		
		List<WebElement> BehaviorHealthApplicationLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_1\"]"));
		System.out.println("BEHAVIOR HEALTH APPLICATION");		
		int size=BehaviorHealthApplicationLinks.size(); 
		System.out.println(size);
		   for(int i=0;i<size;i++){ String name=BehaviorHealthApplicationLinks.get(i).getText();
		  System.out.println(name); }
	}
	
	
public void getCapIntranetApplication() {
	
	System.out.println("CAPITATION INTRANET APPLICATION");
		  List<WebElement> allLinks = driver.findElements(By.tagName("a"));		  
		  System.out.println("All links found on web page are: " + allLinks.size() + " links");		   
		  for (WebElement link : allLinks) {
			  System.out.println(link.getText().trim());		  }
		  List<WebElement> ele= driver.findElements(By.xpath("//input[@type='submit']"));
		  for (WebElement link1 : ele) {
			  System.out.println(link1.getAttribute("value").trim()); 
		  }
		 
	}
			

// This is separate script for only client application
public void getClientApplication() {
	
	List<WebElement> clientApplicationLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_3\"]"));
	System.out.println("CLIENT APPLICATION");	
	int size=clientApplicationLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=clientApplicationLinks.get(i).getText();
	  System.out.println(name); }
}


public void getClientBillingIntranet() {
	
	List<WebElement> clientBillingIntranetLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_4\"]"));
	System.out.println("CLIENT BILLING INTRANET");	
	int size=clientBillingIntranetLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=clientBillingIntranetLinks.get(i).getText();
	  System.out.println(name); }
}


public void getContractAdministrationSystem() {
	
	List<WebElement> ContractAdministrationSystemLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_5\"]"));
	System.out.println("CONTRACT ADMINISTRATION SYSTEM");	
	int size=ContractAdministrationSystemLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=ContractAdministrationSystemLinks.get(i).getText();
	  System.out.println(name); }
	  
	  ////*[@id="rptUserApps_lnkUserAppName_5"]
}
	

public void getDirectServiceTracking() {
	
	List<WebElement> DirectServiceTrackingLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_6\"]"));
	System.out.println("DIRECT SERVICE TRACKING");	
	int size=DirectServiceTrackingLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=DirectServiceTrackingLinks.get(i).getText();
	  System.out.println(name); }
	  
	  // //*[@id="rptUserApps_lnkUserAppName_6"]
}



public void getEncounterSystemIntranet() {
	
	List<WebElement> EncounterSystemIntranetLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_7\"]"));
	System.out.println("ENCOUNTER SYSTEM INTRANET");	
	int size=EncounterSystemIntranetLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=EncounterSystemIntranetLinks.get(i).getText();
	  System.out.println(name); }
	  
	  // //*[@id="rptUserApps_lnkUserAppName_7"]
}

public void getIssueTrackingSystem() {
	
	List<WebElement> IssueTrackingSystemLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_8\"]"));
	System.out.println("ISSUE TRACKING SYSTEM");	
	int size=IssueTrackingSystemLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=IssueTrackingSystemLinks.get(i).getText();
	  System.out.println(name); }
}

public void getOLCRTrackingApplication() {
	
	List<WebElement> OLCRTrackingApplicationLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_9\"]"));
	System.out.println("ISSUE TRACKING SYSTEM");	
	int size=OLCRTrackingApplicationLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=OLCRTrackingApplicationLinks.get(i).getText();
	  System.out.println(name); }
}


public void getPaymentsIntranet() {
	
	List<WebElement> PaymentsIntranetLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_10\"]"));
	System.out.println("PAYMENTS INTRANET");	
	int size=PaymentsIntranetLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=PaymentsIntranetLinks.get(i).getText();
	  System.out.println(name); }
}


public void getPersonnelTrackingSystemIntranet() {
	
	List<WebElement> PersonnelTrackingSystemIntranetLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_11\"]"));
	System.out.println("PERSONNEL TRACKING SYSTEM INTRANET");	
	int size=PersonnelTrackingSystemIntranetLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=PersonnelTrackingSystemIntranetLinks.get(i).getText();
	  System.out.println(name); }
}


public void getProfessionalBillingSystemIntranet() {
	
	List<WebElement> ProfessionalBillingSystemIntranetLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_12\"]"));
	System.out.println("PROFESSIONAL BILLING SYSTEM INTRANET");	
	int size=ProfessionalBillingSystemIntranetLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=ProfessionalBillingSystemIntranetLinks.get(i).getText();
	  System.out.println(name); }
}


public void getProgramMonitoringApplication() {
	
	List<WebElement> ProgramMonitoringApplicationLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_13\"]"));
	System.out.println("PROFESSIONAL MONITORING APPLICATION");	
	int size=ProgramMonitoringApplicationLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=ProgramMonitoringApplicationLinks.get(i).getText();
	  System.out.println(name); }
}


public void getProgramStaffing() {
	
	List<WebElement> ProgramStaffingLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_14\"]"));
	System.out.println("PROGRAM STAFFING");	
	int size=ProgramStaffingLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=ProgramStaffingLinks.get(i).getText();
	  System.out.println(name); }
}


public void getQMIncidentReporting() {
	
	List<WebElement> QMIncidentReportingLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_15\"]"));
	System.out.println("QM INCIDENT REPORTING");	
	int size=QMIncidentReportingLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=QMIncidentReportingLinks.get(i).getText();
	  System.out.println(name); }
}


public void getQMResolutionSystem() {
	
	List<WebElement> QMResolutionSystemLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_16\"]"));
	System.out.println("QM RESOLUTION SYSTEM");	
	int size=QMResolutionSystemLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=QMResolutionSystemLinks.get(i).getText();
	  System.out.println(name); }
}



public void getReportMenuApplication() {
	
	List<WebElement> ReportMenuApplicationLinks = driver.findElements(By.xpath("//*[@id=\"rptUserApps_lnkUserAppName_17\"]"));
	System.out.println("REPORT MENU APPLICATION");	
	int size=ReportMenuApplicationLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=ReportMenuApplicationLinks.get(i).getText();
	  System.out.println(name); }
}


// Global Applications - 3 Main links

public void getClientSearch() {
	
	List<WebElement> ClientSearchLinks = driver.findElements(By.xpath("//*[@id=\"rptGlobalApps_lnkGlobalAppName_0\"]"));
	System.out.println("CLIENT SEARCH");	
	int size=ClientSearchLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=ClientSearchLinks.get(i).getText();
	  System.out.println(name); }
}



public void getVendorSearch() {
	
	List<WebElement> VendorSearchLinks = driver.findElements(By.xpath("//*[@id=\"rptGlobalApps_lnkGlobalAppName_1\"]"));
	System.out.println("VENDOR SEARCH");	
	int size=VendorSearchLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=VendorSearchLinks.get(i).getText();
	  System.out.println(name); }
}


public void getWorkerSearch() {
	
	List<WebElement> WorkerSearchLinks = driver.findElements(By.xpath("//*[@id=\"rptGlobalApps_lnkGlobalAppName_2\"]"));
	System.out.println("WORKER SEARCH");	
	int size=WorkerSearchLinks.size(); 
	System.out.println(size);	  
	  for(int i=0;i<size;i++){ String name=WorkerSearchLinks.get(i).getText();
	  System.out.println(name); }
}




	
}
