package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AdditionalContact {
	public WebDriver driver;

	By ResponFirstName = By.id("ContentPrimary_ctrl_ContactAddress_txtContactFN");
	By ResponLastName = By.id("ContentPrimary_ctrl_ContactAddress_txtContactLN");
	By ResponHomeCheck = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0");	
	By ResponMailCheck = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_1");

	public AdditionalContact (WebDriver driver) {
		this.driver = driver;
	}
}