package com.DDDClient.CommonPages;

public class Links_Validations_DPM {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
