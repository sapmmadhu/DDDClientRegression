package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;


public class Services {
	public WebDriver driver;

	By responfirstname = By.id("ContentPrimary_ctrl_ContactAddress_txtContactFN");
	By responlastname = By.id("ContentPrimary_ctrl_ContactAddress_txtContactLN");
	By responhomecheck = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0");	
	By responmailcheck = By.id("ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_1");

	public Services (WebDriver driver) {
		this.driver = driver;
	}
}