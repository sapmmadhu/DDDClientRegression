package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class AddNewService {
	public WebDriver driver;

	By AddNewServcie = By.xpath("//input[@id='ContentPrimary_lnkAddNewService']");
	By ServiceDropDown = By.xpath("//ctl00$ContentPrimary$ddlService']");
	// Start date and End date same as ISP date- drag and drop down
	By RequestedUnits = By.xpath("//select[@name='ctl00$ContentPrimary$txtRequestedUnits']");
	By ServiceSave = By.xpath("//input[@value='Save']");
			
	public AddNewService(WebDriver driver) {
		this.driver = driver;		
	}

	public WebElement getElement(By element) {
		return driver.findElement(element);
	}
	
	public void consdemo(String language, String ethinicity, String tribe, String incontinent, String emergency, String comments) throws InterruptedException {
		
		/*
		 * Actions actions = new Actions(driver);
		 * actions.moveToElement(this.getElement(DemolangdropDown)).click().build().
		 * perform(); Thread.sleep(5000); //this.getElement(DemolangdropDown).click();
		 * driver.findElement(By.xpath("//span[contains(text(),'"+language+"')]")).click
		 * (); actions.moveToElement(this.getElement(DemoEthdropDown)).click().build().
		 * perform(); //this.getElement(DemoEthdropDown).click();
		 * //this.getElement(DemoTribedropdown).click();
		 * driver.findElement(By.xpath("//span[contains(text(),'"+tribe+"')]")).click();
		 * actions.moveToElement(this.getElement(DemoIncondropdown)).click().build().
		 * perform(); //this.getElement(DemoIncondropdown).click();
		 * driver.findElement(By.xpath(
		 * "//button[@data-id='ContentPrimary_Incontinent_Dropdownlist']//following::div//span[contains(text(),'"
		 * +incontinent+"')]")).click();
		 * actions.moveToElement(this.getElement(DemoEmergencyPaln)).click().build().
		 * perform(); //this.getElement(DemoEmergencyPaln).click(); WebElement ele=
		 * 
		 */			
		
		WebDriverWait wait=new WebDriverWait(driver, 20);
		WebElement DemoComments;
		DemoComments= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath( "//textarea[@name='ctl00$ContentPrimary$txtDisabilityDescription']")));
		DemoComments.sendKeys(comments);		
		Thread.sleep(5000);	
		
		WebElement DemoSave;
		DemoSave =  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='Save']")));
		DemoSave.click();
		
		//actions.moveToElement(this.getElement(DemoSave)).click().build().perform();
		}
	
	
	//links_ConsumerMainMenu.consumerDemographics(consumersLanguage, Ethnicity, Tribe,Incontinent, Emergency Planning, Comments, Reason);
}
