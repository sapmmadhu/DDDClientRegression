package com.DDDClient.CommonPages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;

public class Links_Reports {

	public WebDriver driver;

	By LinkAliases = By.id("lnkConsumerAliases");
	By LinkAddNewAliases = By.id("ContentPrimary_lnkAddNew");
	By LinkViewConsumerList = By.id("ContentPrimary_lnkAddNew");
	public Links_Reports (WebDriver driver) {
		this.driver = driver;
	}
	
	public void Ages6And8() {
		By LinkAges6And8 = By.id("lnkRedetermination");	
		this.driver = driver;		
		}
	
	
	public void Agency() {
		By LinkAgency = By.id("hypAWCProviders");	
		this.driver = driver;		
		}
	
	
	public void CESHigherRateApproval() {
		By LinkCESHigherRateApproval = By.id("lnkCesApproval");	
		this.driver = driver;		
		}
		
	
	public void ClaimsTracking() {
		By LinkClaimsTracking = By.id("lnkClaimsTracking");	
		this.driver = driver;		
		}
	
	
	public void ClaimsTrackingFixedError() {
		By LinkClaimsTrackingFixedError = By.id("lnkClaimsTracking");	
		this.driver = driver;		
		}
	
	
	public void ClaimsNotResearch() {
		By LinkClaimsNotResearch = By.id("lnkALTCS");	
		this.driver = driver;		
		}
	
	
	public void ReviewCycle() {
		By LinkReviewCycle = By.id("lnkReviewCycle");	
		this.driver = driver;		
		}
	
	public void ReviewAnnual() {
		By LinkReviewAnnual = By.id("HYPERLINK4");	
		this.driver = driver;		
		}
	
	
	public void ReviewALTCS() {
		By LinkReviewALTCS = By.id("HYPERLINK5");	
		this.driver = driver;		
		}
		

	public void ReviewTargeted() {
		By LinkReviewTargeted = By.id("lnkTSC");	
		this.driver = driver;		
		}
	
	
	public void ReviewPrior() {
		By LinkReviewPrior = By.id("lnkPrevious");	
		this.driver = driver;		
		}
	
	public void ReviewTimeLiness() {
		By LinkReviewTimeLiness = By.id("lnkTimelinessReview");	
		this.driver = driver;		
		}
	
	
	public void RosterChange() {
		By LinkRosterChange = By.id("lnkRosterChangeReports");	
		this.driver = driver;		
		}
	
	public void RosterChangeIncarceration() {
		By LinkRosterChange = By.id("HyperLink1");	
		this.driver = driver;		
		}
	
	
	public void SIS() {
		By LinkSIS = By.id("hypLinkSISReports");	
		this.driver = driver;		
		}
	
	
	public void Therapy() {
		By LinkTherapy = By.id("lnkTherapyNoShowReports");
		}
	
	public void VendorCall() {
		By LinkVendorCall = By.id("HyperLink8");
		}
	
	
	public void VendorCallAutoAssigned() {
		By LinkVendorCallAutoAssigned = By.id("hlAutoAssigned");
	}
	
	
	
	public void VendorCallDaily() {
		By LinkVendorCallDaily = By.id("hlVendorCallDailyReport");
	}
	
	
	
	
	
	
	
	
	
	
	

}
