package com.DDDClient.CommonPages;

public class Aliases {

}
