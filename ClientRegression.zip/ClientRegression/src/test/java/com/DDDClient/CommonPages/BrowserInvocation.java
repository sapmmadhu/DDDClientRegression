package com.DDDClient.CommonPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserInvocation {
	public WebDriver driver;
	
	public WebDriver BroswerInit() {
		try {	
			//driver = new ieDriver();
			
		//WebDriverManager.iedriver().setup();
		WebDriverManager.chromedriver().setup();
		//File file = new File("C:/Users/C049604/Downloads/IEDriverServer_x64_3.14.0/IEDriverServer.exe");
		//System.setProperty("webdriver.ie.driver", "C:\\Users\\C049604\\Downloads\\IEDriverServer_x64_3.14.0\\IEDriverServer.exe");
		//DesiredCapabilities caps = DesiredCapabilities.internetExplorer();
		//caps.setCapability("EnableNativeEvents", false);
		//caps.setCapability("ignoreZoomSetting", true);
 
		driver = new ChromeDriver();
		//driver = new InternetExplorerDriver(caps);
		//driver = new InternetExplorerDriver();
		Thread.sleep(2500);
		driver.get("http://ddqaweb1.preprod.des:8080/organization/ddd/focusdd/frm_Login.aspx");		
		driver.manage().window().maximize();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return driver;
		
	}

}
