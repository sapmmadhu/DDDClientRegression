package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;



public class HomePage {
	public WebDriver driver;
	
	//By ClientApplication=By.id("MainContent_rptUserApps_lnkUserAppName_0");
	By ClientApplication = By.xpath("//*[@id=\"MainContent_rptUserApps_lnkUserAppName_0\"]");
	
	
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
	}

	public WebElement getElement(By element) {
		return driver.findElement(element);
	}
	public void clientApplication() {
		this.getElement(ClientApplication).click();
					
	}
}
