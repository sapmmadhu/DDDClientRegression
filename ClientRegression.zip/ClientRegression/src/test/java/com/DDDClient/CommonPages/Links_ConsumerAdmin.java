package com.DDDClient.CommonPages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;

public class Links_ConsumerAdmin {

	public WebDriver driver;

	By LinkAliases = By.id("lnkConsumerAliases");
	By LinkAddNewAliases = By.id("ContentPrimary_lnkAddNew");
	By LinkViewConsumerList = By.id("ContentPrimary_lnkAddNew");
	public Links_ConsumerAdmin (WebDriver driver) {
		this.driver = driver;
	}
		
	
	public void AugComAdmin() {
	By LinkAugComAdmin = By.id("lnkAugComm");	
	this.driver = driver;	
		
		}
	
	public void ServiceAuthorizations() {
		//By LinkServiceAuthorizations = By.xpath("//*[text()='Service/Authorizations']");
	}
	
	
	
	public void AugComAdminService() {
		By LinkAugComAdminService = By.id("frm_ISPAugCommClientISP.aspx");	
		this.driver = driver;		
		}
	
	public void BulkConsTransfer() {
		By LinkBulkConsTransfer = By.id("lnkBulkClientTransfer");	
		this.driver = driver;	
		//By LinkBulkConsTransfer = By.xpath("//*[text()='Bulk Consumer Transfer']");
		}
	
	
	public void ClaimsTracking() {
		By LinkClaimsTracking = By.id("lnkClaimsTrackingMenu");	
		this.driver = driver;
		//By LinkClaimsTracking = By.xpath("//*[text()='Claims Tracking']"); 
		}
	
		
	public void DirectCallDates() {
		By LinkDirectCallDates = By.id("lnkAdditionalDates");	
		this.driver = driver;	
		//By LinkDirectCallDates= By.xpath("//*[text()='Direct Call Dates']");
		}
		
	
	public void DirectCallDatesClientID() {
		By LinkDirectCallDatesClientID = By.id("ContentPrimary_Hyperlink1");	
		this.driver = driver;		
		}
		
	
	public void EligiDeterRedeter() {
		By LinkEligiDeterRedeter = By.id("lnkEligibilityDetermination");	
		this.driver = driver;
		//By LinkEligiDeterRedeter= By.xpath("//*[text()='Eligibility Determination/Redetermination']");
		}
	
		
	public void GrantAuth() {
		By LinkGrantAuth = By.id("lnkGrantAuthority");	
		this.driver = driver;	
		//By GrantAuth= By.xpath("//*[text()='Grant Authority']");
		}
	
	
	public void GrantAuthAddNewRecord() {
		By LinkGrantAuthAddNewRecord = By.id("ContentPrimary_lnkNewRecord");
	}
	
	
	public void GrantAuthViewGrant() {
		By LinkGrantAuthAddNewRecord = By.id("ContentPrimary_lnkNewRecord");
	}
	
	
	public void ServiceApprovals() {
		By LinkServiceApprovals = By.id("lnkServiceApprovals");	
		this.driver = driver;	
		//By LinkServiceApprovals= By.xpath("//*[text()='Service Approvals']");
		}
	
	
	
	public void ServiceApprovalStatus() {
		By LinkServiceApprovalStatus = By.id("lnkServiceApprovalRequestStatus");	
		this.driver = driver;
		//By LinkServiceApprovalStatus= By.xpath("//*[text()='Service Approval Status']");
		}
	
	
	
	public void VendorCallQueue() {
		By LinkVendorCallQueue = By.id("lnkVendorCallQueue");	
		this.driver = driver;	
		//By LinkVendorCallQueue= By.xpath("//*[text()='Vendor Call Queue']");
		}
	
	
	public void ViewMyConsumers() {
		By LinkViewMyConsumers = By.id("lnkViewMyConsumers");	
		this.driver = driver;
		//By LinkViewMyConsumers= By.xpath("//*[text()='View My Consumers']");
		}
	
}
