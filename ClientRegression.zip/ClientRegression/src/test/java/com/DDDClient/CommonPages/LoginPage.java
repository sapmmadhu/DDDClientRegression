package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;


public class LoginPage {
	public WebDriver driver;
	
//	By username=By.cssSelector("#txtUserName");
	//txtUserName
	//By username=By.id("MainContent_txtUserName");
	By username =By.name("ctl00$MainContent$txtUserName");
	//By password=By.id("MainContent_txtPassword");
	By password=By.name("ctl00$MainContent$txtPassword");
	//By login=By.id("MainContent_btnLogin");
	By login=By.name("ctl00$MainContent$btnLogin");
	
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
	}

	public WebElement getElement(By element) {
		return driver.findElement(element);
	}
	public void login(String userName, String passWord) {
		this.getElement(username).sendKeys(userName);
		this.getElement(password).sendKeys(passWord);
		this.getElement(login).click();
			
	}
}
