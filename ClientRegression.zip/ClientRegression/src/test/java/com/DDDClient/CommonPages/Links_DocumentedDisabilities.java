package com.DDDClient.CommonPages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;



public class Links_DocumentedDisabilities {
	public WebDriver driver;

	By LinkDocumentedDisabilities = By.id("lnkDocumentedDiabilities");
	By LinkAddFunctionalLimit =By.id("ContentPrimary_lbFuncLimit1");
	By LinkAddEvaluationReport = By.id("ContentPrimary_lbDisablityPrioirty1");

	public Links_DocumentedDisabilities (WebDriver driver) {
		this.driver = driver;
	}
}