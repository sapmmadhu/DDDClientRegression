package com.DDDClient.CommonPages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;

public class Disability {

	public WebDriver driver;

	By ConsumerMenu = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By ViewMyConsumers = By.cssSelector("#lnkViewMyConsumers");
	By MyConsumers = By.id("ContentPrimary_lblRecordCountClients");
	// Should focus consumer name with string, then click on Select
	// Click on Documented disabilities
	// Select Disability and click on Save button
	
	
	// Edit Disability, Change selected Disability and Save
	
}
