package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProgressNotes {
	public WebDriver driver;

	// Progress Notes link from Consumer Main Menu
	By ProgressNotes = By.xpath("lnkProcessNotes']");		
	
	// Text validation
	By PRStartDate = By.xpath("//select[@name='ctl00$ContentPrimary$uccProgressNotes$btnAddNote']");
	By PREndDate = By.xpath("//select[@name='ctl00$ContentPrimary$uccProgressNotes$btnAddNote']");
	By PRAction = By.xpath("//select[@name='ctl00$ContentPrimary$uccProgressNotes$btnAddNote']");
	By PRCategory = By.xpath("//select[@name='ctl00$ContentPrimary$uccProgressNotes$btnAddNote']");
	By PRCorrespondence = By.xpath("//select[@name='ctl00$ContentPrimary$uccProgressNotes$btnAddNote']");
	By PRType = By.xpath("//select[@name='ctl00$ContentPrimary$uccProgressNotes$btnAddNote']");
	By PRGlobalSearch = By.xpath("//select[@name='ctl00$ContentPrimary$uccProgressNotes$btnAddNote']");
	By PRGlobalSearchCheck = By.xpath("//input[@id='ContentPrimary_uccProgressNotes_chkGlobalSearch']");
	
	// Button validation
	By PRSearch = By.xpath("//input[@id='ContentPrimary_uccProgressNotes_btnFilter']");
	By PRReset = By.xpath("//select[@name='ctl00$ContentPrimary$uccProgressNotes$btnResetFilter']");
	By PRPrint = By.xpath("//input[@id='ContentPrimary_uccProgressNotes_btnPrint']");
	By PRAddnote = By.xpath("//select[@name='ctl00$ContentPrimary$uccProgressNotes$btnAddNote']");
	
	// Print pop op buttons
	By PRPrintFinal = By.xpath("//*[@class='action-button']//*[text()='Print']");
	By PRCancelFinal = By.xpath("//*[@class='action-button']//*[text()='Cancel']");
	
	// Add Progress Note
	By PRAddCorres = By.xpath("//a[contains(text(),'OTHER')]");
	By PRAddStart = By.xpath("//input[@id='ContentPrimary_uccProgressNotes_txtStartDate']");
	By PRAddCategory = By.xpath("//a[contains(text(),'ContentPrimary_uccProgressNotes_ddlcategory')]");
	By PRAddNarra = By.xpath("//input[@id='ContentPrimary_uccProgressNotes_txtNotes']");
	By PRAddSave = By.xpath("//select[@name='ctl00$ContentPrimary$uccProgressNotes$btnSave']");
	
	
	public ProgressNotes(WebDriver driver) {
		this.driver = driver;		
	}

	public WebElement getElement(By element) {
		return driver.findElement(element);
	}
	
	public void consProgressNotes(String ProgressNarrative) throws InterruptedException {
		
		WebDriverWait wait=new WebDriverWait(driver, 20);
		Thread.sleep(5000);		
	}
}
