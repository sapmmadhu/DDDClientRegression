package com.DDDClient.CommonPages;




import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ProgressNotes {
	public WebDriver driver;

	By ProgressNotes = By.xpath("lnkProcessNotes']");

	
	
	public ProgressNotes(WebDriver driver) {
		this.driver = driver;
		
	}

	public WebElement getElement(By element) {
		return driver.findElement(element);
	}
	
	public void conseligibility(String EligibilityComments, String ethinicity, String tribe, String incontinent, String emergency, String comments) throws InterruptedException {
		
	
		

		WebDriverWait wait=new WebDriverWait(driver, 20);
		//WebElement EligibilityComments;
		//EligibilityComments= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath( "//textarea[@name='ctl00$ContentPrimary$txtDisabilityDescription']")));
		//EligibilityComments.sendKeys(EligibilityComments);		
		Thread.sleep(5000);
		
		 
				
		WebElement DemoSave;
		DemoSave =  wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@value='Save']")));
		DemoSave.click();
		
		//actions.moveToElement(this.getElement(DemoSave)).click().build().perform();
		
		
	}
	
	
	//links_ConsumerMainMenu.consumerDemographics(consumersLanguage, Ethnicity, Tribe,Incontinent, Emergency Planning, Comments, Reason);
}
