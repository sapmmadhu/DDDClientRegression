package com.DDDClient.CommonPages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;


public class Links_ISPServicePlan {
	public WebDriver driver;

	By LinkISPServicePlan = By.id("lnkServicePlan");
	By LinkISPDateHistory = By.id("ContentPrimary_lnkIspHistory");
	By LinkISPScheduler = By.id("ContentPrimary_ISPScheduler");
	By LinkISPCoverPage = By.id("ContentPrimary_ISPCoverPage");	
	By LinkAddNewService = By.id("ContentPrimary_lnkAddNewService");
	By LinkSubmitEntApproval = By.id("ContentPrimary_lnkSubmitAllPending");
	By LinkDelete = By.id("ContentPrimary_dbgPendingAndApproved_lnkDelete_0");
	By LinkChange = By.id("");
	By LinkCommentsAndOutcomes = By.id("ContentPrimary_dbgPendingAndApproved_lnkCommentsAndGoals_0");
	By LinkSubmitChangeApproval = By.id("ContentPrimary_lnkSubmitAllChangePending");

	public Links_ISPServicePlan (WebDriver driver) {
		this.driver = driver;
	}
}