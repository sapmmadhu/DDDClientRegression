package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class Eligibility {
	public WebDriver driver;

	By EligiDeterButton = By.xpath("//select[@name='ctl00$btnDetermineEligibility']");
	By EligiDeterRedeter = By.xpath("//input[@id='lnkEligibilityDetermination']");
	By EligiYesButton = By.xpath("//select[@name='ctl00$ContentPrimary$Eligible']");
	By EligiDeterNotes =  By.xpath("//textarea[@name='ctl00$ContentPrimary$txtNotes']");
	By EligiSave =  By.xpath("//textarea[@name='ctl00$ContentPrimary$btnSaveContinue']");
	By EligiViewMyConsumers = By.xpath("lnkViewMyConsumers");	
	By EligiWorkerDropDown = By.xpath("//select[@name='ctl00$ContentPrimary$ddlWorkerType']");
	By EligiClientDropDown = By.xpath("//select[@name='ctl00$ContentPrimary$ddlClient']");
	By EligiMyConsumers = By.xpath("//input[@id='ContentPrimary_lblRecordCountClients']");
	By EligiStatus = By.xpath("//*[text()='APPROVED']");
	
	// The below line prompts after select client with latest record on top, so can select DDD as first record
	//By EligiSelect = By.xpath("//a[contains(@href='ctl00$ContentPrimary$dbgClients$ctl03$lnkCID')]/@href");
	//a[text()='ctl00$ContentPrimary$dbgClients$ctl03$lnkCID']/@href
	//a[contains(@href,'ctl00$ContentPrimary$dbgClients$ctl03$lnkCID')
	//input[@id='ContentPrimary_dbgClients_lnkCID_0']");
		
	
	public Eligibility(WebDriver driver) {
		this.driver = driver;		
	}

	public WebElement getElement(By element) {
		return driver.findElement(element);
	}
	
	public void conseligibility(String EligibilityComments) throws InterruptedException {		
		
		Actions actions = new Actions(driver);
		// Click on DDD Eligibility button, after that action the DDD eligibility button should be disable view
		this.getElement(EligiDeterButton);
		Thread.sleep(5000);
		// Click on Consumer Administration and click on Eligibility determination/ Redetermination
		this.getElement(EligiDeterRedeter);
		Thread.sleep(5000);
				
		// Match the consumer name and to click on Edit link
		WebElement eleme = driver.findElement(By.xpath("//span[text()='ConsumerName']"));
		String strng = eleme.getText();
		System.out.println(strng);
		Assert.assertEquals("ConsumerName", strng);
		
		// Yes Radio button
		this.getElement(EligiYesButton);
		Thread.sleep(5000);
		// Eligibility notes
		this.getElement(EligiDeterNotes).sendKeys(EligibilityComments);
		Thread.sleep(5000);
		// Eligibility Save
		this.getElement(EligiSave);
		Thread.sleep(5000);
		
		// Click on Consumer admin and go to View my consumers
		this.getElement(EligiViewMyConsumers);		
		
		 
		 actions.moveToElement(this.getElement(EligiWorkerDropDown)).click().build().perform(); 
		 Thread.sleep(5000); 		 		 
		 		 
		 actions.moveToElement(this.getElement(EligiClientDropDown)).click().build().perform(); 
		 Thread.sleep(5000); 		 	
		 
		 // Search result, click on My Consumers
		 this.getElement(EligiMyConsumers);		 
		 // Click on Select button after match the name string in consumer  search result
		 this.getElement(EligiSave).click();
		 
		 // ISP service plan view for the selected consumer with approved status as APPROVED
		 this.getElement(EligiStatus);		
		 System.out.println(EligiStatus);	
		 
		 
	}
}
