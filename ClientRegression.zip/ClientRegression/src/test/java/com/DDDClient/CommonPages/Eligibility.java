package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class Eligibility {
	public WebDriver driver;
	By consumerMainMenu = By.xpath("//li[@id='liConsumerMenu']//a[contains(text(),'Consumer Main Menu')]");
	By EligiDDDButton = By.xpath("//input[@name='ctl00$btnDetermineEligibility']");
	By consumer_Admin= By.xpath("//a[contains(text(),'Consumer Administration ')]");
	By EligiDeterRedeter = By.xpath("//a[contains(text(),'Eligibility Determination/Redetermination')]");
	By EligiYesButton = By.xpath("//input[@id='ContentPrimary_RadioButton1']");
	By EligiNoButton = By.xpath("//input[@id='ContentPrimary_RadioButton2']");
	By EligiDeterNotes =  By.xpath("//textarea[@name='ctl00$ContentPrimary$txtNotes']");
	By EligiFinalSave =  By.xpath("//input[@value='Save']");
	By EligiSuccmsg = By.xpath("//span[contains(text(),'Save Successful')]");
	By EligiViewMyConsumers = By.xpath("//a[contains(text(),'View My Consumers')]");	
	By EligiWorkerDropDown = By.xpath("//div[contains(text(),'PRIMARY')]");
	By EligiClientDropDown = By.xpath("//div[contains(text(),'--SELECT--')]");
	By EligiMyConsumers = By.xpath("(//a[@data-toggle='collapse'])[1]");
	By EligiStatus = By.xpath("//*[text()='APPROVED']");
	By EligiSelect = By.xpath("//a[contains(text(),'Select')]");
	
		
	//td[contains(text(),'DAY MAY')]//parent::tr//a[contains(text(),'Edit')]
	public Eligibility(WebDriver driver) {
		this.driver = driver;		
	}

	public WebElement getElement(By element) {
		return driver.findElement(element);
	}
	
	public void consEligibility(String lastName, String firstName, String workType, String client) throws InterruptedException {		
		
		this.getElement(consumerMainMenu).click();
		Thread.sleep(6000);
		this.getElement(EligiDDDButton).click();
		Thread.sleep(6000);
		this.getElement(consumer_Admin).click();
		Thread.sleep(5000);
		this.getElement(EligiDeterRedeter).click();
		Thread.sleep(5000);
		int size=driver.findElements(By.xpath("//td[contains(text(),'"+lastName+" "+firstName+"')]")).size();
		Thread.sleep(5000);
		System.out.println("size=="+size);
		//(//td[contains(text(),'MAY MON')])[3]//parent::tr//a[starts-with(@id,'ContentPrimary_dbgEligibilityDates_hypClient_3')]
		//WebDriverWait wait = new WebDriverWait(driver, 60);
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[contains(text(),'"+lastName+" "+firstName+"')]//parent::tr//a[@id='ContentPrimary_dbgEligibilityDates_hypClient_0']")));
		String id=driver.findElement(By.xpath("(//td[contains(text(),'"+lastName+" "+firstName+"')])["+size+"]//parent::tr//a[@id='ContentPrimary_dbgEligibilityDates_hypClient_"+size+"']")).getText();
		Thread.sleep(5000);
		driver.findElement(By.xpath("(//td[contains(text(),'"+lastName+" "+ firstName+"')])["+size+"]//parent::tr//a[contains(text(),'Edit')]")).click();
		Thread.sleep(5000);
		this.getElement(EligiYesButton).click();
		Thread.sleep(5000);
		this.getElement(EligiFinalSave).click();
		Thread.sleep(5000);
		System.out.println("Save message: "+this.getElement(EligiSuccmsg).getText());
		Thread.sleep(5000);
		this.getElement(consumer_Admin).click();
		Thread.sleep(5000);
		this.getElement(EligiViewMyConsumers).click();
		Thread.sleep(5000);
		this.getElement(EligiWorkerDropDown).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//span[contains(text(),' Worker Type:')]//parent::div//span[contains(text(),'"+workType+"')]")).click();
		Thread.sleep(5000);
		this.getElement(EligiClientDropDown).click();
		Thread.sleep(5000);
		WebElement dropDownEle=driver.findElement(By.xpath("//select[@id='ContentPrimary_ddlClient']"));
		Select select= new Select(dropDownEle);
		select.selectByValue(id);
		//driver.findElement(By.xpath("//(//span[contains(text(),'"+lastName+" "+ firstName+"')])[1]")).click();
		Thread.sleep(5000);		
				
		this.getElement(EligiMyConsumers).click();
		Thread.sleep(5000);
		this.getElement(EligiSelect).click();
		
		
		//span[contains(text(),' Worker Type:')]//parent::div//span[contains(text(),'COURTESY')]
		//(//span[contains(text(),'DAY MAY')])[1]
		
		//td[contains(text(),'DAY MAY')]
		//td[contains(text(),'DDD')]
		//a[contains(text(),'Select')]
		
		//Match the consumer full  name, Client ID from Consumer eligibility determination page and match that ID from DOM with value, name
        // and then select the particular Consumer ID from the drop down		
		// Click on " My Consumer" row and click on Select button by mouse hover after match clientID
		 
		
	}
}
