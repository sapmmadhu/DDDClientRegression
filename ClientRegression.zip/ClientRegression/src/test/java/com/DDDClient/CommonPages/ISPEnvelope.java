package com.DDDClient.CommonPages;

public class ISPEnvelope {

}
