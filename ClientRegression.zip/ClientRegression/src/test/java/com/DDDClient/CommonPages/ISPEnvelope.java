package com.DDDClient.CommonPages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ISPEnvelope {
	public WebDriver driver;

	By ISPServicePlan = By.id("lnkServicePlan");
	By ISPAnnualCompDate = By.xpath("//input[@id='ContentPrimary_txtAnnual']");
	By ISPReviewCompDate = By.xpath("//input[@id='ContentPrimary_txtAnnual']");
	By ISPCreateNew = By.xpath("//input[@value='Create New ISP Envelope']");
	

	
	public ISPEnvelope(WebDriver driver) {
		this.driver = driver;
		
	}

	public WebElement getElement(By element) {
		return driver.findElement(element);
	}
	
	
	public void ISPEnvelope (String language, String ethinicity, String tribe, String incontinent, String emergency, String comments) throws InterruptedException {
		
		Actions actions = new Actions(driver);
		actions.moveToElement(this.getElement(ISPServicePlan)).click().build().perform();
		Thread.sleep(5000);
		// Annual completed date and Review completed date - Calendar
		
		WebElement  ele=	driver.findElement(By.xpath("//span[contains(text(),'Emergency Planning:')]//following::div//following::div//span[contains(text(),'"+emergency+"')]"));
		actions.moveToElement(ele).doubleClick().build().perform();
		Thread.sleep(5000);
			
		WebDriverWait wait=new WebDriverWait(driver, 20);
		WebElement DemoComments;
		
		this.getElement(ISPCreateNew);			
		
		
		// Handling alert message after click on New Envelope
		 Alert alert = driver.switchTo().alert();
		 String alertMessage= driver.switchTo().alert().getText();	
		 System.out.println(alertMessage);
		 Thread.sleep(3000);
		 alert.accept();
		 
	}
	
}
