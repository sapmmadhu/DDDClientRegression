package com.DDDClient.CommonPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;

public class Links_CaseStatus {
	public WebDriver driver;

	By LinkCaseStatus = By.id("lnkCaseStatus");
	By LinkAddNewCaseStatus = By.id("ContentPrimary_lnkAddNew");
	
	
	public Links_CaseStatus (WebDriver driver) {
		this.driver = driver;
	}
}