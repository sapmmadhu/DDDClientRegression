package com.DDDClient.common;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import static org.openqa.selenium.support.ui.ExpectedConditions.elementToBeClickable;
import static org.openqa.selenium.support.ui.ExpectedConditions.presenceOfElementLocated;
import static org.openqa.selenium.support.ui.ExpectedConditions.textToBePresentInElementLocated;
import org.apache.*;
import org.junit.Before;
import org.junit.BeforeClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.ie.InternetExplorerDriver; 
import java.util.concurrent.TimeUnit;
import com.google.common.base.Function;


import io.github.bonigarcia.wdm.WebDriverManager;
import java.io.PrintStream;

public class BrowserInvocation {
	public WebDriver driver;
	
	
	
    @BeforeClass
    public static void setupClass() {
        WebDriverManager.iedriver().setup();
    }

    @Before
    public void setupTest() {
        driver = new InternetExplorerDriver();
    }
    
    
	public WebDriver BroswerInit() {		
		try {			
		//WebDriverManager.setup();		
		WebDriver driver=new InternetExplorerDriver();
		Thread.sleep(2500);
		driver.manage().window().maximize();
		driver.get("http://ddqaweb1.preprod.des:8080/organization/ddd/focusdd/frm_Login.aspx");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		}catch(Exception e) {
			e.printStackTrace();
		}
		return driver;		
	}

}
