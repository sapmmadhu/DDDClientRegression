package com.DDDClient.common;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class LoginPage {
	public WebDriver driver;
	
	By username=By.cssSelector("#txtUserName");
	By password=By.cssSelector("#txtPassword");
	By login=By.cssSelector("#btnLogin");
	
	
	
	public LoginPage(WebDriver driver) {
		this.driver=driver;
	}

	public WebElement getElement(By element) {
		return driver.findElement(element);
	}
	public void login() {
		this.getElement(username).sendKeys("D013174");
		this.getElement(password).sendKeys("dddtesting");
		this.getElement(login).click();
			
	}
}
