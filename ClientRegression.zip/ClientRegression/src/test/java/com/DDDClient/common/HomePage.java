package com.DDDClient.common;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {
	public WebDriver driver;
	
	By clientApplication=By.cssSelector("#rptUserApps_lnkUserAppName_0");
	
	
	
	public HomePage(WebDriver driver) {
		this.driver=driver;
	}

	public WebElement getElement(By element) {
		return driver.findElement(element);
	}
	public void clientApplication() {
		this.getElement(clientApplication).click();
					
	}
}
