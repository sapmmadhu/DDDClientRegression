package com.DDDClient.common;

import java.util.Set;

import org.openqa.selenium.WebDriver;

public class WindowHandler {

	public WebDriver driver;

	public WindowHandler(WebDriver driver) {
		this.driver = driver;
	}

	public void tabsHandler() {
		String currentHandle = driver.getWindowHandle();
		Set<String> handles = driver.getWindowHandles();
		for (String handle : handles) {
			if (!handle.equals(currentHandle)) {
				driver.switchTo().window(handle);
			}
		}
	}
}
