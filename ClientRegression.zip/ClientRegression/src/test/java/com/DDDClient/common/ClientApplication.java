package com.DDDClient.common;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver; 

public class ClientApplication {
	public WebDriver driver;

	By consumerMenu = By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a");
	By viewMyConsumers = By.cssSelector("#lnkViewMyConsumers");
	By addClientButton = By.id("ContentPrimary_btnAddClient");
	By addLastName = By.id("ContentPrimary_txtLastName");
	By addFirstName = By.id("ContentPrimary_txtFirstName");
	By addGender = By.name("ctl00$ContentPrimary$ddlGender");
	By addDOB = By.cssSelector("#ContentPrimary_txtDOB");
	By addDOBContinue = By.cssSelector("#ContentPrimary_btnAddAndContinue");
	By referrredCheckBox = By.cssSelector("#ContentPrimary_dgNewAdd_chkReferred_0");
	By addContinueLink = By.cssSelector("#ContentPrimary_dgNewAdd_Linkbutton2_0");

	public ClientApplication(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getElement(By element) {
		return driver.findElement(element);
	}

	public void viewConsumers() {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		//wait.until(ExpectedConditions.elementToBeClickable(consumerMenu)).click();
		//wait.until(ExpectedConditions.elementToBeClickable(viewMyConsumers)).click();
	}

	public void addConsumers() {
		try {
			this.getElement(addClientButton).click();
			this.getElement(addLastName).sendKeys("abcd");
			this.getElement(addFirstName).sendKeys("defg");

			WebElement Gender = driver.findElement(addGender);
			Thread.sleep(6000);
			Select select = new Select(Gender);
			select.selectByValue("M");

			this.getElement(addDOB).sendKeys("01/01/2017");
			this.getElement(addDOBContinue).click();

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,1000)");

			Thread.sleep(7000);
			this.getElement(referrredCheckBox).click();
			this.getElement(addContinueLink).click();			
			Thread.sleep(5000);
			//driver.switchTo().alert().accept();
			//Thread.sleep(3000);

			//((JavascriptExecutor) driver).executeScript("window.scrollBy(0, -250)", "");

		} catch (Exception e) {
			e.printStackTrace();
		}

	}		public void alertCheck() {
			Alert alert= driver.switchTo().alert();
			String alertMessage=driver.switchTo().alert().getText();
			System.out.println("alert message:"+alertMessage);
		}
			
		// If Javascript Alert is present on the page cancels it.		
		public void handleAlert(){		
		if(isAlertPresent()){		
		Alert alert = driver.switchTo().alert();		
		System.out.println(alert.getText());		
		alert.accept();		
		}		
		}	 	
		
		//* @return True if JavaScript Alert is present on the page otherwise false		
		public boolean isAlertPresent(){		
		try{		
		driver.switchTo().alert();		
		return true;		
		}catch(NoAlertPresentException ex){		
		return false;
		}
		}

}
