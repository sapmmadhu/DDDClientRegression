package com.DDDClient.test;

public class AddPaidServiceATC {

}
