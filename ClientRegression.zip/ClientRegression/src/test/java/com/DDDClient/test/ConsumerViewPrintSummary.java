package com.DDDClient.test;


import org.testng.annotations.Test;

import com.DDDClient.utilities.ExcelUtil;
import com.DDDClient.utilities.*;

public class ConsumerViewPrintSummary {

	@Test
	public void getValue() {
		String firstCellData=ExcelUtil.getCellData("Sheet1", 0, 0);
		System.out.println("firstCellData: "+firstCellData);
			
		
		ExcelUtil.setCellData("data to be entered", "Sheet1", 10, 10);
		String tenthCellData=ExcelUtil.getCellData("Sheet1", 10, 10);
		System.out.println("tenthCellData: "+tenthCellData);					
	}

}
