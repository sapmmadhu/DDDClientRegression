package com.DDDClient.test;

// Kids DOB more than 10, and Add this Disability before DDD Eligible request. After approval, SC is changing 
// Level of Cognitive Intellectual Disability

public class EditLevelOfCognitiveIntellectualDisability {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
