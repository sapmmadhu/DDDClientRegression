package com.DDDClient.test;

import java.util.HashMap;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.DDDClient.CommonPages.BrowserInvocation;
import com.DDDClient.CommonPages.ClientApplication;
import com.DDDClient.CommonPages.HomePage;
import com.DDDClient.CommonPages.LoginPage;
import com.DDDClient.common.WindowHandler;
import com.DDDClient.utilities.ExcelReader;

import org.apache.poi.ss.usermodel.*;

public class RequestDDDEligibility {
	public WebDriver driver;
	
	@Test
	public void getName() {
		ExcelReader reader= new ExcelReader();
		HashMap<Integer, String> firstNameMap = reader.getData("firstName");
		HashMap<Integer, String> lastNameMap = reader.getData("lastName");
		HashMap<Integer, String> genderMap = reader.getData("gender");
		HashMap<Integer, String> dateofBirthMap = reader.getData("dateOfBirth");		
		BrowserInvocation browserInvocation = new BrowserInvocation();
		driver=browserInvocation.BroswerInit();
		LoginPage loginPage = new LoginPage(driver);
		//loginPage.login(userName, passWord);
		
		HomePage homePage= new HomePage(driver);
		homePage.clientApplication();
		
		WindowHandler windowHandler= new WindowHandler(driver);
		windowHandler.tabsHandler();
		for(int i=0;i<firstNameMap.size();i++)
		{		
		ClientApplication clientApplication = new ClientApplication(driver);
		clientApplication.viewConsumers();
				
		System.out.println("first Name: "+firstNameMap.get(i)+" last Name: "+lastNameMap.get(i));		
		clientApplication.addConsumers(firstNameMap.get(i), lastNameMap.get(i), genderMap.get(i),dateofBirthMap.get(i));
		
		//clientApplication.addConsumers(lastNameMap.get(i));

		clientApplication.isAlertPresent();
		clientApplication.redirectpopop();
		System.out.println(i+" is done");
		driver.close();
		}	
		driver.quit();				
	}
}
