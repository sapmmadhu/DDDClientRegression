package com.DDDClient.tests;

public class EditAdditionalContactAddress {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
