package com.DDDClient.tests;

public class AddEditConsumerAddress {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
