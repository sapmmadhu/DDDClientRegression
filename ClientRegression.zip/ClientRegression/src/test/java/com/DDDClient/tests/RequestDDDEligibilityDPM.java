package com.DDDClient.tests;

public class RequestDDDEligibilityDPM {

}
