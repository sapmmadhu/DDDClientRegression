package com.DDDClient.tests;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.DDDClient.CommonPages.BrowserInvocation;
import com.DDDClient.CommonPages.LoginPage;
import com.DDDClient.common.WindowHandler;
//import com.DDDClient.CommonPages.Links_Validations_SC;

public class Links_Validations_SCTest {
	public WebDriver driver;
	
	@Test
	public void areLinksAvailable() {

		BrowserInvocation browserInvocation = new BrowserInvocation();
		driver = browserInvocation.BroswerInit();

		LoginPage loginPage = new LoginPage(driver);
		loginPage.login("C044925", "dddtesting");
		
		/*Links_Validations_SC link = new Links_Validations_SC(driver);
		List<WebElement> userAppsList=link.getUserAppsList();
		link.getGlobalApps();
		
		for(int i=0;i<userAppsList.size();i++) {
		
		if(userAppsList.get(i).getText().contains("AHCCCS UTILITIES")) {
			userAppsList.get(i).click();
			WindowHandler handler= new WindowHandler(driver);
	        handler.tabsHandler();
	        Links_Validations_SC link1 = new Links_Validations_SC(driver);
			link1.getAHCCCSUtilities();
			break;}}		
		driver.quit();
	}*/

}
}