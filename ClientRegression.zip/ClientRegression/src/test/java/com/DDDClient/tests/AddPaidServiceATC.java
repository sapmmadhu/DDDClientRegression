package com.DDDClient.tests;

public class AddPaidServiceATC {

}
