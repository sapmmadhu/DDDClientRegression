package com.DDDClient.tests;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.DDDClient.CommonPages.BrowserInvocation;
import com.DDDClient.CommonPages.ClientApplication;
import com.DDDClient.CommonPages.Demographics;
import com.DDDClient.CommonPages.Eligibility;
import com.DDDClient.CommonPages.HomePage;
import com.DDDClient.CommonPages.Links_ConsumerMainMenu;
import com.DDDClient.CommonPages.LoginPage;
import com.DDDClient.CommonPages.ProgressNotes;
import com.DDDClient.CommonPages.ResponsibleParty;
import com.DDDClient.common.WindowHandler;
import com.DDDClient.utilities.ExcelApiTest;

public class RequestDDDEligibilitySC {
	public WebDriver driver;
	String xlFilePath = "P:/Selenium/Data.xlsx";
	String sheetName = "Sheet1";
	ExcelApiTest eat = null;

	@Test(dataProvider = "userData")
	public void getName(String testCaseNo, String scUsername, String scPassword, String firstName, String lastName,
			String gender, String dateofBirth, String reFirstName, String reLastName, String reSelectbox,
			String reAddlineone, String reAddlinetwo, String reCity, String reState, String reZip, String reHomePhone,
			String disabilityName, String functionalLimit, String functionalLimitOne, String functionalLimitTwo,
			String ERName, String ERTitle, String typeOFEvaluation, String etiologyName, String language, String ethinicity, String tribe, String incontinent,
			String emergency, String comments)
			throws InterruptedException, IOException {
		try {

			BrowserInvocation browserInvocation = new BrowserInvocation();
			driver = browserInvocation.BroswerInit();
			//BrowserInvocation browserInvocation = new BrowserInvocation();
			LoginPage loginPage = new LoginPage(driver);
			loginPage.login(scUsername, scPassword);

			HomePage homePage = new HomePage(driver);
			homePage.clientApplication();

			WindowHandler windowHandler = new WindowHandler(driver);
			windowHandler.tabsHandler();

			ClientApplication clientApplication = new ClientApplication(driver);
			Thread.sleep(5000);
			clientApplication.viewConsumers();
			clientApplication.addConsumers(firstName, lastName, gender, dateofBirth);

			WebDriverWait wait = new WebDriverWait(driver, 300);
			if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
				clientApplication.isAlertPresent();
			}
			Thread.sleep(5000);
			clientApplication.redirectpopop();

			ResponsibleParty responsibleParty = new ResponsibleParty(driver);
			responsibleParty.addResponsibleParty(reFirstName, reLastName, reSelectbox, reAddlineone, reAddlinetwo,
					reCity, reState, reZip, reHomePhone);
			Thread.sleep(5000);
			Links_ConsumerMainMenu links_ConsumerMainMenu = new Links_ConsumerMainMenu(driver);
			links_ConsumerMainMenu.linkDocumentedDisabilities();
			links_ConsumerMainMenu.consumerDocumentedDisabilities(disabilityName, functionalLimit, functionalLimitOne, functionalLimitTwo, ERName, ERTitle,typeOFEvaluation, etiologyName);
			// links_ConsumerMainMenu.evaluationReport(Name, Title, TypeER, DateOfReport);
			
			Demographics demographics= new Demographics(driver);
			demographics.consdemo(language, ethinicity, tribe, incontinent, emergency, comments);
			Thread.sleep(5000);
			
		    // The below line is for to start Eligibility request and approval process
			//Eligibility eligibility = new Eligibility(driver);
			//eligibility.conseligibility(EligibilityComments);
			// driver.close();
			
			
			// Progress notes validation
			//ProgressNotes progressnotes = new ProgressNotes(driver);
			//progressnotes.consProgressNotes(ProgressNarrative);
			//Thread.sleep(5000);
			
			
		} catch (Exception e) {
			e.printStackTrace();
			File screenshotFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
			FileUtils.copyFile(screenshotFile, new File("C:/Selenium/" + testCaseNo + ".png"));
		}
	}

	@DataProvider(name = "userData")
	public Object[][] userFormData() throws Exception {
		Object[][] data = testData(xlFilePath, sheetName);
		return data;
	}

	public Object[][] testData(String xlFilePath, String sheetName) throws Exception {
		Object[][] excelData = null;
		eat = new ExcelApiTest(xlFilePath);
		int rows = eat.getRowCount(sheetName);
		int columns = eat.getColumnCount(sheetName);

		excelData = new Object[rows - 1][columns];

		for (int i = 1; i < rows; i++) {
			for (int j = 0; j < columns; j++) {
				// excelData[i - 1][j] = eat.getCellData(sheetName, j, i);
				excelData[i - 1][j] = eat.getCellValueAsString(sheetName, j, i);
			}
		}
		return excelData;
	}
}
