package com.DDDClient.tests;

public class AddUpdateSearchProgressNotes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
