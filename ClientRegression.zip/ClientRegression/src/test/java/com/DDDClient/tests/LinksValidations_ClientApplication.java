package com.DDDClient.tests;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LinksValidations_ClientApplication {

	public static void main(String firstName, String lastName, String gender, String dateofBirth) {
		
	}

    

	}


