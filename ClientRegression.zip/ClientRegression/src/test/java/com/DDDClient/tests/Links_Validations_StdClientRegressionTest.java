package com.DDDClient.tests;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.DDDClient.CommonPages.BrowserInvocation;
import com.DDDClient.CommonPages.LoginPage;
import com.DDDClient.common.WindowHandler;
import com.DDDClient.CommonPages.Links_Validations_StdClientRegression;

public class Links_Validations_StdClientRegressionTest {
	public WebDriver driver;
	public Links_Validations_StdClientRegression link;
	public WindowHandler windowHandler;

	@Test
	public void areLinksAvailable() {
		BrowserInvocation browserInvocation = new BrowserInvocation();
		driver = browserInvocation.BroswerInit();
		LoginPage loginPage = new LoginPage(driver);
		loginPage.login("C044925", "dddtesting");
		link = new Links_Validations_StdClientRegression(driver);
		List<WebElement> userAppsList = link.getUserAppsList();
		// link.getGlobalApps();
		for (WebElement linkTest : userAppsList) {
			switch (linkTest.getText()) {
			case "CAPITATION INTRANET APPLICATION": 
				// windowHandler.tabsHandler();
				linkTest.click();
				windowHandler = new WindowHandler(driver);
				windowHandler.tabsHandler();
				link.getCapIntranetApplication();
				break;
			default: break;					
			}			
		}
		
		/*
		 * for(int i=0;i<userAppsList.size();i++) { String
		 * text=userAppsList.get(i).getText();
		 * 
		 * switch(userAppsList.get(i).getText()) {
		 * 
		 * 
		 * case "AHCCCS UTILITIES": userAppsList.get(i).click(); windowHandler= new
		 * WindowHandler(driver); windowHandler.tabsHandler();
		 * link.getAHCCCSUtilities(); driver.close();
		 * 
		 * //break;
		 * 
		 * case "CAPITATION INTRANET APPLICATION":{ //windowHandler.tabsHandler();
		 * userAppsList.get(i).click(); windowHandler= new WindowHandler(driver);
		 * windowHandler.tabsHandler(); link.getCapIntranetApplication(); break; }
		 * 
		 * } //break;
		 * 
		 * continue; }
		 */
		driver.quit();
	}

}
