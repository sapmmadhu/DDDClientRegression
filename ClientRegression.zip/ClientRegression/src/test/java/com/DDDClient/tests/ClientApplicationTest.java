package com.DDDClient.tests;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;
import com.DDDClient.CommonPages.BrowserInvocation;
import com.DDDClient.CommonPages.LoginPage;
import com.DDDClient.common.WindowHandler;
import com.DDDClient.CommonPages.ClientApplication;
import com.DDDClient.CommonPages.Links_Validations_StdClientRegression;

public class ClientApplicationTest {
	public WebDriver driver;
	public ClientApplication ClientApplication;
	public WindowHandler windowHandler;
	
@Test
public void ClientApplication() {	
	BrowserInvocation browserInvocation = new BrowserInvocation();
	driver = browserInvocation.BroswerInit();
	LoginPage loginPage = new LoginPage(driver);
	loginPage.login("D031826", "dddtesting");		
	
	WebElement element = driver.findElement(By.id("rptUserApps_lnkUserAppName_0"));
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	executor.executeScript("arguments[0].click();", element);
	
	
		/*
		 * WebElement elem =
		 * driver.findElement(By.xpath(".//*[@id='__dialog1-footer']/button[1]/div"));
		 * // This will enable this element if element is invisible String js =
		 * "arguments[0].style.height='auto'; arguments[0].style.visibility='visible';";
		 * // Execute the Java Script for the element which we find out
		 * ((JavascriptExecutor) driver).executeScript(js, elem); // Click on element
		 * elem.click();
		 */
	
	
	windowHandler = new WindowHandler(driver);
	windowHandler.tabsHandler();	    
		/*
		 * public void doubleClickElement(); 
		 * public void viewConsumers(); 
		 * public void addConsumers(); 
		 * public boolean isAlertPresent();
		 */	
}
}


