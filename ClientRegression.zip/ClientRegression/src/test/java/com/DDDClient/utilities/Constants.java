package com.DDDClient.utilities;

public class Constants {
	
	public static final String filePath="C:\\Users\\C049604\\Desktop\\Data.xlsx";
	

}
