package com.DDDClient.utilities;

import org.testng.annotations.AfterTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod; 
import org.testng.annotations.AfterMethod;

 
public class ExcelToDataProvider {
     
    String xlFilePath = "C:/Selenium/Data.xlsx";
    String sheetName = "Sheet1";
    ExcelApiTest eat = null;
     
    @Test(dataProvider = "userData")
    public void fillUserForm(String firstName, String lastName, String gender, String dateofBirth)
    {    	
    	
       System.out.println("firstName: "+ firstName);
       System.out.println("LastName: "+ lastName);
       System.out.println("Gender: "+ gender);
       System.out.println("DOB: "+ dateofBirth);
       System.out.println("*********************");
       
    }
    
     
    
     
    @DataProvider(name="userData")
    public Object[][] userFormData() throws Exception
    {
        Object[][] data = testData(xlFilePath, sheetName);
        return data;
    }
     
    public Object[][] testData(String xlFilePath, String sheetName) throws Exception
    {
        Object[][] excelData = null;
        eat = new ExcelApiTest(xlFilePath);
        int rows = eat.getRowCount(sheetName);
        int columns = eat.getColumnCount(sheetName);
             
        excelData = new Object[rows-1][columns];
         
        for(int i=1; i<rows; i++)
        {
            for(int j=0; j<columns; j++)
            {
               // excelData[i-1][j] = eat.getCellData(sheetName, j, i);
                excelData[i-1][j] = eat.getCellValueAsString(sheetName, j, i);
            }

        }
        return excelData;
    }
}