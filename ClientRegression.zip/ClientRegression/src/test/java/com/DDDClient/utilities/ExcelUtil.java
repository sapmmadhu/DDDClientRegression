package com.DDDClient.utilities;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.ss.usermodel.DataFormatter;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.IOException;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtil {
	public static FileInputStream file;
	public static XSSFWorkbook excelWorkBook;
	public static XSSFSheet excelSheet;
	public static XSSFRow excelRow;
	public static XSSFCell excelCell;
	

	public static String getCellData( String sheetName, int rowNum, int colNum) {
		String cellData = null;
		try {
			file = new FileInputStream(Constants.filePath);
			excelWorkBook = new XSSFWorkbook(file);
			excelSheet = excelWorkBook.getSheet(sheetName);
			excelRow = excelSheet.getRow(rowNum);
			excelCell = excelRow.getCell(colNum);
			DataFormatter formatter = new DataFormatter();
			cellData = formatter.formatCellValue(excelCell);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return cellData;
	}
	
	
	public static void setCellData( String text,  String sheetName, int rowNum, int colNum) {
		try {
			file = new FileInputStream(Constants.filePath);
			excelWorkBook = new XSSFWorkbook(file);
			excelSheet = excelWorkBook.getSheet(sheetName);
				excelRow = excelSheet.createRow(rowNum);
			excelCell = excelRow.createCell(colNum);
			excelCell.setCellValue(text);
			 FileOutputStream fos=new FileOutputStream(Constants.filePath);
			 excelWorkBook.write(fos);
			 fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	
}


