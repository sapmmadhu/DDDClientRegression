package com.DDDClient.utilities;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import bsh.Console;

public class ExcelReader {

	public static final String SAMPLE_XLSX_FILE_PATH = "C:/Selenium/Data.xlsx";	
	Consumers consumers = new Consumers();
	HashMap<Integer, Consumers> map = new HashMap<Integer, Consumers>();
	HashMap<Integer, String> firstNameMap = new HashMap<Integer, String>();
	HashMap<Integer, String> lastNameMap = new HashMap<Integer, String>();
	HashMap<Integer, String> genderMap = new HashMap<Integer, String>();
	HashMap<Integer, String> dateOfBirthMap = new HashMap<Integer, String>();

	// @Test
	public HashMap<Integer, String> getData(String columnName) {
		try {

			Workbook workbook = WorkbookFactory.create(new File(SAMPLE_XLSX_FILE_PATH));

			// System.out.println("\n\nIterating over Rows and Columns using for-each
			// loop\n");

			int rowId;
			Sheet sheet = workbook.getSheet("Sheet1");
			DataFormatter dataFormatter = new DataFormatter();

			for (Row row : sheet) {
				rowId = row.getRowNum();
				//System.out.println("row id:" + rowId);
				if (rowId != 0) {
					Cell firstName = row.getCell(0);
					Cell lastName = row.getCell(1);
					Cell gender = row.getCell(2);
					Cell dateOfBirth= row.getCell(3);
					List<? extends Object> data= printCellValue(dateOfBirth);
					System.out.println(data);
					if (firstName != null)

						consumers.setFirstName(dataFormatter.formatCellValue(firstName));
					if (lastName != null)
						consumers.setLastName(dataFormatter.formatCellValue(lastName));
					
					if(gender!=null)
						consumers.setGender(dataFormatter.formatCellValue(gender));

					if(dateOfBirth!=null) {
						
						String dob= dataFormatter.formatCellValue(dateOfBirth);
						System.out.println("dob:"+ dob);			
						
						
						 consumers.setDateOfBirth(dataFormatter.formatCellValue(dateOfBirth));
		              
					}
					map.put(rowId, consumers);

				}
				// workbook.close();
			}
			//System.out.println("Size: " + map.size());
			int i = 0;
			for (Consumers mapObj : map.values()) {

				String firstName = mapObj.getFirstName().trim();
				String lastName = mapObj.getLastName().trim();
				String gender = mapObj.getGender().trim();
				String dateOfBirth = mapObj.getDateOfBirth();
				firstNameMap.put(i, firstName);
				lastNameMap.put(i, lastName);
				genderMap.put(i, gender);
				dateOfBirthMap.put(i, dateOfBirth);
				
				i++;
			}

			switch (columnName) {
			case "firstName":
				return firstNameMap;
			case "lastName":
				return lastNameMap;
			case "gender":
				return genderMap;
			case "dateOfBirth":
				return dateOfBirthMap;
			}
			/*for (int j = 0; j < firstNameMap.size(); j++) {
				System.out.println(j + " " + firstNameMap.get(j));
				System.out.println(j + " " + lastNameMap.get(j));
			}
*/
		} catch (Exception e) {
			e.printStackTrace();
		}
		return firstNameMap;
	}
	Boolean b;
	String s,f;
	Date d;
	 double i;
	public   List<? extends Object> printCellValue(Cell cell) {
		//DataFormatter dataFormatter = new DataFormatter();
	    switch (cell.getCellTypeEnum()) {
	        case BOOLEAN:
	            System.out.print(cell.getBooleanCellValue());
	             b= cell.getBooleanCellValue();
	            
	            break;
	        case STRING:
	            System.out.print(cell.getRichStringCellValue().getString());
	            s= cell.getRichStringCellValue().getString();
	            break;
	        case NUMERIC:
	            if (DateUtil.isCellDateFormatted(cell)) {
	            	System.out.print(cell.getDateCellValue());
	             d=cell.getDateCellValue();
	                
	            } else {
	                System.out.print(cell.getNumericCellValue());
	                i= cell.getNumericCellValue();
	            }
	            break;
	        case FORMULA:
	            System.out.print(cell.getCellFormula());
	             f=cell.getCellFormula();
	            break;
	        case BLANK:
	            System.out.print("");
	            break;
	        default:
	            System.out.print("");
	    }

	    System.out.print("\t");

		return Arrays.asList(b, s, i,b,f);
	}
	

}
