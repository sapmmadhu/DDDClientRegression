package com.DDDClient.utilities;

import org.testng.annotations.Test;

public class ExcelToDataProviderTest {
  @Test
  public void f() {
  }
}
