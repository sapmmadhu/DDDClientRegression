package tests;
import java.awt.AWTException;
import java.awt.List;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.Select;
import io.github.bonigarcia.wdm.WebDriverManager;

@Test
public class LoginPage {

	public WebDriver driver;	
	public void Search() throws InterruptedException, AWTException, IOException {
		Thread.sleep(5000);			
		
		
		/*	System.setProperty("webdriver.ie.driver",  "C:\\Selenium\\IEDriverServer_x64_3.14.0\\IEDriverServer.exe");
		//driver = new ChromeDriver();
		WebDriver driver=new InternetExplorerDriver();				
    
		/* System.setProperty("webdriver.gecko.driver","C:\\Selenium\\geckodriver-v0.21.0-win64.exe");
		 WebDriver driver = new FirefoxDriver(); */		
		
		/*System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");		
		WebDriver driver = new ChromeDriver();	*/
		
		
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver();
		Thread.sleep(2500);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		
		driver.get("http://ddqaweb1.preprod.des:8080/organization/ddd/focusdd/frm_Login.aspx");		
		driver.manage().window().maximize();
		
		driver.findElement(By.cssSelector("#txtUserName")).sendKeys("D013174");
		//driver.findElement(By.xpath("//input[@name=�txtPassword�]")).sendKeys("dddtesting");
		driver.findElement(By.cssSelector("#txtPassword")).sendKeys("dddtesting");
		//driver.findElement(By.xpath("//input[@type=�submit�]")).click();;	
		driver.findElement(By.cssSelector("#btnLogin")).click();
		driver.findElement(By.cssSelector("#rptUserApps_lnkUserAppName_0")).click();
		
				
		Thread.sleep(4000);
		
		// Switching the Windows
		
		       String  currentHandle= driver.getWindowHandle();				       
			   Set<String> handles= driver.getWindowHandles();
			   for(String handle: handles){
			   if(!handle.equals(currentHandle)){
			   driver.switchTo().window(handle);
			   }
			   }	
			   
			   Thread.sleep(6000);
			   
  
			  WebDriverWait wait = new WebDriverWait(driver,10);
			//First click on dropdown down to open options
			wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a"))).click();
			//Now select opened option
			wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#lnkViewMyConsumers"))).click();
			
			
			
			// Validate the SC belongs to correct district or not
			
			
			
			// Click on Add Consumer
			
			driver.findElement(By.id("ContentPrimary_btnAddClient")).click();
			driver.findElement(By.id("ContentPrimary_txtLastName")).sendKeys("abc");
			driver.findElement(By.id("ContentPrimary_txtFirstName")).sendKeys("def");
			
			
			
			// This is drop down value to select Gender
			WebElement Gender = driver.findElement(By.name("ctl00$ContentPrimary$ddlGender"));
			Thread.sleep(6000);
			Select select = new Select(Gender);
			select.selectByValue("M");			
			
						
			// DOB			
			driver.findElement(By.cssSelector("#ContentPrimary_txtDOB")).sendKeys("01/01/2017");
			driver.findElement(By.cssSelector("#ContentPrimary_btnAddAndContinue")).click();
			
			// Scroll bar down to bottom of the page by 1000 pixel vertical			
			js.executeScript("window.scrollBy(0,1000)");

			
			/*// Scroll down
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0,250)", "");
			//Scroll Up
			((JavascriptExecutor) driver).executeScript("window.scrollBy(0, -250)", "");
			*/
			
			
			// Referred Check box
			driver.findElement(By.cssSelector("#ContentPrimary_dgNewAdd_chkReferred_0")).click();
			
			// Add and continue link
			driver.findElement(By.cssSelector("#ContentPrimary_dgNewAdd_Linkbutton2_0")).click();
					
			// This is auto generated alert. Can not able to take the property. so we can consider this is Alert. This should be handled		
			   System.out.println(driver.switchTo().alert().getText());
			   Thread.sleep(5000);
		       driver.switchTo().alert().accept();
		       Thread.sleep(3000);
		       
		     //Scroll Up
				((JavascriptExecutor) driver).executeScript("window.scrollBy(0, -250)", "");
				
				Thread.sleep(5000);
		       
		       // This is 2nd pop op, Consider this is NOT alerts. Because we are able to catch the web element. Can use click operation.
		       driver.findElement(By.xpath("//*[@id=\"myModal\"]/div/div/div[3]/button")).click();
		       //new WebDriverWait(driver, 20).until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"myModal\"]/div/div/div[3]/button"))).click();
			
			
			// Responsible party	
		       
		       //Without filling details, SC clicks on Save
		       driver.manage().window().maximize();	
		       js.executeScript("window.scrollBy(0,1000)");		
		       Thread.sleep(3000);
		       driver.findElement(By.cssSelector("#ContentPrimary_ctrl_ContactAddress_btnSave")).click();
		       
		       // click on OK button from the pop op "Please enter Valid address line"
		       System.out.println(driver.switchTo().alert().getText());
			   Thread.sleep(5000);
		       driver.switchTo().alert().accept();
		       Thread.sleep(3000);
		       
		       // To maximize the Chrome browser
		       driver.manage().window().maximize();
		       
		       driver.findElement(By.cssSelector("#ContentPrimary_ctrl_ContactAddress_txtContactFN")).sendKeys("man");
		       driver.findElement(By.cssSelector("#ContentPrimary_ctrl_ContactAddress_txtContactLN")).sendKeys("first");
		       
		       // To maximize the Chrome browser
		       driver.manage().window().maximize();
		       
		       // Home Check Box		       
		       driver.findElement(By.cssSelector("#ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_0")).click();
		       
		       // Mailing Check Box
		       driver.findElement(By.cssSelector("#ContentPrimary_ctrl_ContactAddress_chkAddNewAddr_1")).click();
		       
			   // Address line box
		       driver.findElement(By.cssSelector("#ContentPrimary_ctrl_ContactAddress_txtAddressLine1")).sendKeys("Elliots Crossings");
		       // Address line 2
		       driver.findElement(By.cssSelector("#ContentPrimary_ctrl_ContactAddress_txtAddressLine2")).sendKeys("200");
		       
		       driver.findElement(By.cssSelector("#ContentPrimary_ctrl_ContactAddress_txtCity")).sendKeys("TEMPE");
		       driver.findElement(By.cssSelector("#ContentPrimary_ctrl_ContactAddress_txtZip5")).sendKeys("85283");
		       
		       // Home Phone
		       driver.findElement(By.cssSelector("#ContentPrimary_ctrl_ContactAddress_txtHomePhonePrefixSuffix")).sendKeys("4804527896");
		       
		       // Calendar - click to open the date time picker calendar     		       
		       
		       // click to open the date time picker calendar with name property
		       /*  WebElement calElement = driver.findElement(By.name("ctl00$ContentPrimary$ctrl_ContactAddress$txtAddressStDate"));
		       calElement.click();*/
		       
		       
		       // click to open the date time picker calendar with css selector
				/*	WebElement calElement = driver.findElement(By.cssSelector("#ContentPrimary_ctrl_ContactAddress_pnlAddressDates > table > tbody > tr:nth-child(1) > td:nth-child(2) > div > span > span"));
					calElement.click();*/
		       
		       //click to open the date time picker calendar with id property
		       WebElement calElement = driver.findElement(By.id("ContentPrimary_ctrl_ContactAddress_txtAddressStDate"));
		       calElement.click();
		       
		       						 
			   // Click on "Today"  inside the Calendar 
			    WebElement today = driver.findElement(By.cssSelector("#masterPage > div:nth-child(3) > div.datetimepicker-days > table > tfoot > tr:nth-child(1) > th"));
			    today.click();
			    
			    // Save button
			    driver.findElement(By.id("ContentPrimary_ctrl_ContactAddress_btnSave")).click();
			 			    
			    Thread.sleep(10000);
			    ((JavascriptExecutor) driver).executeScript("window.scrollBy(0, -250)", "");
			    
			   // Address validation alert			    
			    driver.findElement(By.cssSelector("#ssaddressdialog > div:nth-child(1) > div:nth-child(2) > div > div:nth-child(2) > input")).click();
			   
			    Thread.sleep(5000);
			    driver.findElement(By.cssSelector("#myModal > div > div > div.modal-footer > button")).click();
			    Thread.sleep(3000);
			    driver.manage().window().maximize();
			    // Requesting "Determine DDD eligibility" from Consumer main menu
			    driver.findElement(By.cssSelector("#liConsumerMenu")).click();
			    driver.findElement(By.id("btnDetermineEligibility")).click();
			    Thread.sleep(3000);
			    
				// To close child window
				driver.close();
				// To close parent window
				driver.switchTo().window(currentHandle);
				
			    
		
			// Log in as a Supervisor "D028090" To approve DDD Eligibility - //  Click on Consumer Admin --> Eligibility Determination/ Re Determination -
				driver.get("http://ddqaweb1.preprod.des:8080/organization/ddd/focusdd/frm_Login.aspx");		
				driver.manage().window().maximize();
			    
				driver.findElement(By.cssSelector("#txtUserName")).sendKeys("D028090");
				//driver.findElement(By.xpath("//input[@name=�txtPassword�]")).sendKeys("dddtesting");
				driver.findElement(By.cssSelector("#txtPassword")).sendKeys("dddtesting");
				//driver.findElement(By.xpath("//input[@type=�submit�]")).click();;	
				
				
				driver.findElement(By.cssSelector("#btnLogin")).click();
				driver.findElement(By.cssSelector("#rptUserApps_lnkUserAppName_0")).click();
				 driver.manage().window().maximize();	
				Thread.sleep(6000);
							   
					// Switching the Windows
						
				       String  currentHandle1= driver.getWindowHandle();				       
					   Set<String> handles1= driver.getWindowHandles();
					   for(String handle: handles){
					   if(!handle.equals(currentHandle)){
					   driver.switchTo().window(handle);
					   }
					   }	
					   
					   WebDriverWait wait1 = new WebDriverWait(driver,10);
						//First click on dropdown down to open options
						wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#bs-example-navbar-collapse-1 > ul:nth-child(2) > li:nth-child(3) > a"))).click();
						//Now select opened option
						wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("#lnkEligibilityDetermination"))).click();
			    
			
						// Add some Disability conditions in "Consumer documented disabilities" screen - Save
			
			//  Click on Consumer Admin --> Eligibility Determination/ Re Determination  - Notes, Edit, and then approve it for DDD
			
			
			
			// Again login as SC "D013174 "  - Consumer Admin --> View My consumers --> My Consumers records
			
			
			// Here verify newly added consumer has got DDD eligibility or no, Search with Consumer name
			
			
			// Click on Select, and focus on top left corner to make sure that ASSIST id, Case status -OPEN or not
			
			
			// ISP screen -  SC makes an action to add annual date by click on "Annual Completed Date", Click on "Create New ISP Envelope"
			
			
			// Verify this message pop ops or not - FOCUS ISP Date and New ISP Envelope Successfully Created
			
			
			// Again ISP screen - Click on "Add New Service", Service as "ATC" , Start date and End date should fall betweeb Consumer ISP start and end dates from the top of the screen
			// Requested units - 10,  Give some comments and SAVE
			
		    //  This is for to create Authorization to find vendors,  Consumer Main Menu--> Vendor Selection & Authorization
	
		   // Create New authorization with start and end date with in "Service dates" which is showing in the same screen, 
			
			
			// Click on "ByPass Vendor Call, select and desired vendors (A Brighter Avenue, L.L.C.), Save & Continue, Select Office and Save& Continue, Levels Of Service(10)
			// Add requested units which is lower than "Total Available units" - Validate more values
			// Click "Authorize"
			
			// Verify newly created authorization is showing under  "Finalized Authorizations:"
			
			
			
			
			// login as Vendor in Web2 - http://ddqaweb2/organization/ddd/focusdd/frm_Login.aspx to give Authorization, abrighteravenue0909, dddtesting
			
			
			
			// Click on Service authorizations --> Pending authorizations --> Find Client name and Accept the Auths
			
			
						
			
		        }
		        }

			
			
			
